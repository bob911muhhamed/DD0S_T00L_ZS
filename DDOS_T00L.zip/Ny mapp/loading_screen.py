# loading_animation.py
from pystyle import *
import os
import time
import subprocess

def show_loading_animation():
    os.system('clear' if os.name == 'posix' else 'cls')

    intro = """
 _____ _    _ _   _ ____  _     _____ _   _    _    _     
|  ___| |  | | \ | / ___|| |   | ____| \ | |  / \  | |    
| |_  | |  | |  \| \___ \| |   |  _| |  \| | / _ \ | |    
|  _| | |__| | |\  |___) | |___| |___| |\  |/ ___ \| |___ 
|_|   |_____/|_| \_|____/|_____|_____|_| \_/_/   \_\_____|
                                                         
                > Press Enter                                         
    """

    Anime.Fade(Center.Center(intro), Colors.black_to_red, Colorate.Vertical, interval=0.035, enter=True)
    os.system('clear' if os.name == 'posix' else 'cls')